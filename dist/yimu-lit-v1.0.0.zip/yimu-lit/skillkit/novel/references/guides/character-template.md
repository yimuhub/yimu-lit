---
name: novel-references-guides-character-template
title: 人物档案模板
medium: [novel]
stages: [P0]
kind: template
weight: 3
license: MIT
source: 原创（神笔小说 ShenBi NovelCraft，方法论吸收业界通用创作思想）
---

# 人物档案 · 模板（原创）

复制填写；主要角色全部字段必填，配角可省第 9、10。

```
## 人物：<姓名>
- 姓名/称谓：全名__；<谁>叫 ta <什么>
- 时代/年龄：__
- 身份/资源：职业__，掌握资源__
- 性格内核：<一句可预测压力的话>
- 想要 Want：__
- 欠缺 Need：__
- 代价 Cost：__
- 说话方式：<句式/口头禅>；绝对不用：__
- 关系/立场：与主角__，立场__（帮/阻/利用/情感）
- 知情范围：此刻知道__；不知道__
- 弧光：开局__ → 转折__ → 终局__
- 标志细节：<物件/动作/习惯>
```

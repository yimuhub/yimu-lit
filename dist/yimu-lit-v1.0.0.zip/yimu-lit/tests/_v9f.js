
const $=id=>document.getElementById(id);
const sid=(localStorage.nbot_sid||(localStorage.nbot_sid=crypto.randomUUID()));
let curKey=null, timer=null, polling=false;
const msgBox=$('msgs');

function bubble(who,html,cls,plain){
  const d=document.createElement('div');
  d.className='msg '+who+(cls?' '+cls:'');
  d.innerHTML=`<div class="ava">${who==='bot'?'🖋':'🙂'}</div><div class="bubble">${html}</div>`;
  msgBox.appendChild(d); msgBox.scrollTop=msgBox.scrollHeight;
  // v0.4.1：per-book 对话隔离 —— 传了纯文本 plain 且当前有绑定书，就写进这本书自己的对话记录
  if(typeof plain==='string' && _chatKey()) pushBkChat(_chatKey(), who, plain);
  return d;
}
// ===== v0.4.1：每本书独立的对话（点哪本书，中间只看到它自己的聊天）=====
function _chatKey(){ return curSession||curKey||''; }
function pushBkChat(key,who,text){
  if(!text||!text.trim())return;
  fetch('/api/bkchat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({key,who,text:text.trim().slice(0,2000)})}).catch(()=>{});
}
async function loadBkChat(key){
  msgBox.innerHTML='';
  if(!key)return;
  const tk=_viewToken;   // v0.6 A：切书后弃旧响应，防上一本书的对话串进来
  let d={messages:[]};
  try{ d=await (await fetch('/api/bkchat?key='+encodeURIComponent(key))).json(); }catch(e){}
  if(tk!==_viewToken)return;
  const ms=d.messages||[];
  if(!ms.length){
    const it=(window._libCache||[]).find(x=>x.key===key);
    bubble('bot','💬 已切换到 <b>'+esc(it?it.name:key)+'</b> 的专属对话（只属于这本书）。直接告诉我要做什么：改剧情 / ⏸暂停 / ▶续写 / 🔓放行 / 加修正指令……','');
    if(window.rwDialogueCheck)rwDialogueCheck(key);   // v0.8.0 恢复该书的重写 live/结果气泡
    return;
  }
  ms.slice(-80).forEach(m=>{ bubble(m.who||'bot', fmt(m.text||''), '', null); });
  if(window.rwDialogueCheck)rwDialogueCheck(key);   // v0.8.0 恢复该书的重写 live/结果气泡
}
function esc(s){s=(s==null)?'':String(s);return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}
// v0.7.x：LLM 慢动作「活体进度」引擎——转圈+已等待秒数+防双击。用法：
//   const busy=busyStart('create',$('oberr'),'📐 规划中（选题→人物→大纲→细纲 + 书名候选）');
//   ... await 慢请求 ...（成功/失败 finally 里）busy.stop();
const _busy={};
function busyStart(id, el, base, btn){
  if(_busy[id]) _busy[id].stop();                 // 防同键重入（双击/连点）
  const t0=Date.now(); let stopped=false;
  const show=()=>{ if(stopped||!el)return; const s=Math.round((Date.now()-t0)/1000);
    el.innerHTML='<span class="busymsg"><span class="byspin"></span>'+esc(base)+' · 已等待 <b>'+s+'</b> 秒…'+(s>=40?'（本地模型较慢，后台仍在生成，别重复点）':'')+'</span>'; };
  show(); const iv=setInterval(show,1000);
  if(btn){ btn.dataset._bt=btn.textContent; btn.disabled=true; }
  const stop=()=>{ stopped=true; clearInterval(iv); delete _busy[id]; if(btn){ btn.disabled=false; if(btn.dataset._bt)btn.textContent=btn.dataset._bt; } };
  _busy[id]={stop}; return {stop};
}
// 快速判断某键是否在跑（供按钮 onclick 前置守卫，避免连点）
function isBusy(id){ return !!_busy[id]; }
// v0.2.1 UX：轻提示 / 骨架 / 模态统一关闭
function toast(msg,type){
  const t=document.createElement('div'); t.className='toast '+(type||''); t.innerHTML=msg;
  $('toasts').appendChild(t); setTimeout(()=>{t.style.transition='opacity .4s';t.style.opacity='0';setTimeout(()=>t.remove(),400);},3200);
}
function skel(n){ let h=''; for(let i=0;i<(n||3);i++)h+='<div class="skel"></div>'; return h; }
function bindModalClose(){
  document.querySelectorAll('.modal').forEach(m=>{
    m.addEventListener('click',e=>{ if(e.target===m) m.classList.remove('show'); });
  });
  document.addEventListener('keydown',e=>{ if(e.key==='Escape') document.querySelectorAll('.modal.show').forEach(m=>m.classList.remove('show')); });
}
function fmt(s){
  return esc(s)
    .replace(/(【\d+】|✅|⚠️|📐|📚|✍️|🔁|💥)/g,'<b>$1</b>')
    .replace(/\*\*(.+?)\*\*/g,'<b>$1</b>')
    .replace(/(^|\n)(📖|🧑|💥|🌍|👁|🎨|💡|📚|📊|✅|⚠️)([^\n]*)/g,'$1<b>$2</b><span style="color:var(--text)">$3</span>');
}
function thinking(){
  const d=document.createElement('div');
  d.className='msg bot'; d.id='think';
  d.innerHTML='<div class="ava">🖋</div><div class="bubble thinking"><span class="dot"></span><span class="dot"></span><span class="dot"></span> 构思中…</div>';
  msgBox.appendChild(d); msgBox.scrollTop=msgBox.scrollHeight;
}
function killThinking(){const t=$('think'); if(t)t.remove();}

async function send(){
  const v=$('inp').value.trim(); if(!v)return;
  $('inp').value='';
  bubble('user',fmt(v),'',v);
  thinking();
  // v0.5 M3：中间台自然语言指令 → 结构化动作（改写某段/某章/全书/看评分）；非指令才走聊天
  {
    const k=_curKey();
    if(k){
      try{
        const cr=await (await fetch('/api/cmd',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({key:k,text:v})})).json();
        if(cr&&cr.action&&cr.action!=='chat'){ killThinking(); execCmd(cr,v); return; }
      }catch(e){}
    }
  }
  const pid=$('pselect')?$('pselect').value:'', mid=$('mselect')?$('mselect').value:'';
  const payload={session_id:sid,message:v};
  if(pid)payload.provider_id=pid;
  if(mid)payload.model=mid;
  try{
    const r=await fetch('/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify(payload)});
    const j=await r.json();
    killThinking();
    const bb=bubble('bot',fmt(j.reply||'(空回复)'),'', j.reply||null);
    attachTitleCards(bb, j.reply||'');
    if(j.project){curKey=j.project; curSession=j.project;
      // v0.4.1：把开书这条对话记进新书自己的记录（开书=这本书的第一条专属对话）
      pushBkChat(j.project,'user',v); pushBkChat(j.project,'bot', j.reply||'');
    }
    refreshProjects();
  }catch(e){killThinking();bubble('bot','⚠️ 服务异常：'+e,'',null);}
}
// 聊天里 bot 报"请选书名【1】..【N】" → 渲染成可点卡片（点一下=发送编号）
function attachTitleCards(d, text){
  if(!/【1】《/.test(text)) return;
  const ms=[...text.matchAll(/【(\d+)】《([^》]+)》/g)].slice(0,8);
  if(!ms.length || !d) return;
  const row=document.createElement('div');
  row.style.cssText='display:flex;flex-wrap:wrap;gap:6px;margin-top:8px;align-items:center';
  row.innerHTML='<span style="font-size:11px;color:var(--muted)">🎯 点选书名：</span>'+
    ms.map(m=>'<span class="libchip" data-n="'+m[1]+'" style="cursor:pointer">'+esc(m[2])+'</span>').join('');
  row.querySelectorAll('.libchip').forEach(c=>c.onclick=()=>{ c.style.opacity=.5; $('inp').value=c.dataset.n; send(); });
  d.querySelector('.bubble').appendChild(row);
}
// ===== v0.4：Agent 式随时控（箭头随状态变换：➤发送 / ■停止 / ▶继续 / ⚡发指令）=====
function _libItem(k){ if(!k)return null; return (window._libCache||[]).find(x=>x.key===k)||null; }
function _curKey(){ return curSession||curKey||null; }
function dispatchSend(){
  const it=_libItem(_curKey());
  const running=it&&it.state==='in_progress'&&!it.paused;
  const paused=it&&it.paused;
  const hasText=$('inp').value.trim().length>0;
  if(running&&!hasText){ pauseBook(); return; }            // ■ 停止
  if(paused&&!hasText){ resumeBook(); return; }             // ▶ 继续
  if((running||paused)&&hasText){ queueInstruction(true); return; } // ⚡立即发这条修正指令
  send();                                                    // ➤ 正常聊天 / 开新指令
}
$('send').onclick=dispatchSend;
$('stage').onclick=()=>queueInstruction(false);            // ＋待发送（暂存）
$('inp').addEventListener('input',updateSendBtn);
$('inp').addEventListener('keydown',e=>{
  if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();dispatchSend();}
});
function updateSendBtn(){
  const it=_libItem(_curKey());
  const running=it&&it.state==='in_progress'&&!it.paused;
  const paused=it&&it.paused;
  const hasText=$('inp').value.trim().length>0;
  const sendEl=$('send'), stageEl=$('stage');
  sendEl.classList.remove('stop','qsend');
  if(running||paused){
    stageEl.style.display='';
    if(hasText){ sendEl.textContent='⚡发'; sendEl.classList.add('qsend'); sendEl.title='立即发送这条修正指令（下一章立刻用上）'; }
    else if(running){ sendEl.textContent='■'; sendEl.classList.add('stop'); sendEl.title='停止（暂停当前写作）'; }
    else { sendEl.textContent='▶'; sendEl.title='继续写作（恢复）'; }
  } else { stageEl.style.display='none'; sendEl.textContent='➤'; sendEl.title='发送'; }
  updateQbar();
}
function pauseBook(){ const k=_curKey(); if(!k)return toast('先选一本书','err');
  fetch('/api/pause',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({key:k})}).then(x=>x.json()).then(j=>{toast(j.msg||'已暂停','ok');renderSessions();startPolling();updateSendBtn();}).catch(()=>{}); }
function resumeBook(){ const k=_curKey(); if(!k)return toast('先选一本书','err');
  fetch('/api/resume',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({key:k})}).then(x=>x.json()).then(j=>{toast(j.msg||'继续中','ok');curSession=k;renderSessions();startPolling();switchView('ms');updateSendBtn();}).catch(()=>{}); }
function queueInstruction(imm){ const k=_curKey(), t=$('inp').value.trim(); if(!k)return toast('先选一本书','err'); if(!t)return;
  fetch('/api/queue',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({key:k,text:t,immediate:!!imm})}).then(x=>x.json()).then(j=>{
    if(j.ok){ $('inp').value=''; updateQbar(); updateSendBtn(); toast(imm?'⚡ 指令已立即生效（下一章立刻用上）':'＋ 已暂存为「待发送」（下一条自动用上）','ok'); }
    else toast(j.error||'加入失败','err');
  }).catch(()=>{}); }
async function updateQbar(){
  const k=_curKey(), bar=$('qbar'); if(!k){bar.innerHTML='';return;}
  try{
    const d=await (await fetch('/api/queue?key='+encodeURIComponent(k))).json();
    const items=d.items||[];
    if(!items.length){bar.innerHTML='';return;}
    bar.innerHTML=items.map(q=>'<div class="qitem'+(q.immediate?' imm':'')+'" data-i="'+q.i+'"><span>'+(q.immediate?'⚡':'⏳')+'</span><span class="qt">'+esc(q.text)+'</span>'+(q.immediate?'':'<button class="qa" data-a="imm">▶立即</button>')+'<button class="qa" data-a="rm">✕</button></div>').join('');
    bar.querySelectorAll('.qa').forEach(b=>b.onclick=async()=>{
      const i=+b.parentElement.dataset.i, a=b.dataset.a;
      await fetch('/api/queue/action',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({key:k,index:i,action:a==='rm'?'remove':'imm'})});
      updateQbar();
    });
  }catch(e){}
}

function startPolling(){
  if(polling)return; polling=true;
  timer=setInterval(async()=>{
    if(!curKey)return;
    try{
      const j=await (await fetch('/api/status?key='+encodeURIComponent(curKey))).json();
      if(j.error)return;
      $('prog').style.display='block';
      $('pname').textContent='《'+(j.name||curKey)+'》';
      const pct=j.total?Math.round(j.done/j.total*100):0;
      $('pfill').style.width=pct+'%';
      $('pinfo').textContent=j.done+'/'+j.total+' 章 · '+(j.state==='completed'?'✅ 完成':j.state==='in_progress'?'✍️ 创作中':j.state==='validating'?'🔁 校验中':j.state);
      $('pwords').textContent=j.words+' 字';
      $('evts').innerHTML=(j.events||[]).slice(-8).map(e=>'<div>'+esc(e)+'</div>').join('');
      // v0.3.5：中间「稿件」实时刷新 —— 正在写/校验时，小说正文随进度逐章出现（事件仍留右侧）
      if($('manuscript').style.display==='block'){ loadManuscript(curKey); }
      // v0.7.x：中间「对话」逐章直播 —— 正在写时随轮询逐字推进、写满一章出新气泡；写完后定格一次
      if($('msgs').style.display!=='none' && window.loadChatLive){
        const _w=['in_progress','validating','releasing'].includes(j.state);
        if(_w || loadChatLive._lastW===curKey){ loadChatLive(curKey); loadChatLive._lastW=_w?curKey:null; }
      }
      // v0.3.5：左侧书行「正在写第X章/校验第N轮」实时刷新
      if(j.state==='in_progress'||j.state==='validating'||j.state==='releasing'){ if(window.renderSessions)renderSessions(); }
      if(j.state==='completed'){refreshProjects();}
      if(window.updateSendBtn)updateSendBtn();
    }catch(e){}
  },4000);
}

function refreshProjects(){ loadLibrary(); if(window.renderSessions)renderSessions(); }

// ===== 作品库管理（v0.2）=====
const L={sort:'updated',order:'desc',genre:'',status:'',q:'',sel:new Set()};
function libQuery(){
  const p=new URLSearchParams();
  p.set('sort',L.sort); p.set('order',L.order);
  if(L.genre)p.set('genre',L.genre);
  if(L.status)p.set('status',L.status);
  if(L.q)p.set('q',L.q);
  return p.toString();
}
async function loadLibrary(){
  if(!loadLibrary._loaded){ $('plist').innerHTML=skel(4); loadLibrary._loaded=true; }
  let d; try{ d=await (await fetch('/api/library?'+libQuery())).json(); }catch(e){return;}
  if(!d.items)return;
  const s=d.stats;
  $('libstats').innerHTML = (L.status==='archived'?'🗑 回收站 · '+s.count+' 本':
    '共 <b>'+s.count+'</b> 本 · 达标 <span class="qok">'+s.passing+'</span> / 未评 '+s.unrated+
    ' · 均分 <b>'+(s.avg_quality==null?'—':s.avg_quality)+'</b> · 总字数 <b>'+(s.total_words||0)+'</b>');
  const gs=(d.facets&&d.facets.genres)||[];
  $('libgenre').innerHTML='<label>题材</label>'+gs.map(g=>
    '<span class="libchip'+(L.genre===g?' on':'')+'" data-g="'+esc(g)+'">'+esc(g)+'</span>').join('');
  $('libgenre').querySelectorAll('[data-g]').forEach(c=>c.onclick=()=>{L.genre=(L.genre===c.dataset.g?'':c.dataset.g);L.status='';syncChips();loadLibrary();});
  const el=$('plist');
  if(!d.items.length){el.innerHTML='<div class="empty">'+(L.status==='archived'?'回收站为空':'暂无作品')+'</div>';}
  else el.innerHTML=d.items.map(i=>{
    const qb=i.quality==null?'<span class="qbadge na">未审</span>':(i.passing?'<span class="qbadge pass">'+i.quality+'</span>':'<span class="qbadge fail">'+i.quality+'</span>');
    const rel=(i.released===true)?'<span class="qbadge pass" style="margin-left:5px">放行✅</span>':(i.released===false?'<span class="qbadge fail" style="margin-left:5px">未放行 ⚠️'+(i.final_quality!=null?('/'+(i.pass_line||90)):'')+'</span>':'');
    const tag=i.state==='completed'?'<span class="tag done">完成</span>'
      :(i.running?'<span class="tag run">创作中</span>':'<span class="tag wait">'+esc(i.status_label||i.state)+'</span>');
    const sel=L.sel.has(i.key);
    let act='<div style="display:flex;flex-wrap:wrap;gap:6px;margin-top:8px">';
    if(L.status==='archived'){ act+='<button class="pb" data-key="'+i.key+'" data-op="restore">♻ 恢复</button>'; }
    else{
      act+='<button class="pb prev" data-key="'+i.key+'" data-op="prev">👁 预览</button>';
      if(i.awaiting_title && !i.running){ act+='<button class="pb run" data-key="'+i.key+'" data-op="picktitle">✍ 选书名</button>'; }
      else if(i.state==='completed'){ act+='<a class="pb" href="/api/download?key='+encodeURIComponent(i.key)+'" target="_blank" onclick="event.stopPropagation()">⬇ 成书</a><button class="pb run" data-key="'+i.key+'" data-op="cx">▶ 续写</button>'; }
      else if(i.running){ act+='<button class="pb" disabled style="opacity:.5">创作中…</button>'; }
      else{ act+='<button class="pb" data-key="'+i.key+'" data-op="cont">▶ 继续写</button>'; }
    }
    act+='</div>';
    return '<div class="pitem" data-key="'+i.key+'" onclick="pick(\''+i.key+'\')">'+
      '<span class="fav'+(i.favorite?' on':'')+'" data-key="'+i.key+'" onclick="toggleFav(event,this)" title="收藏">'+(i.favorite?'★':'☆')+'</span>'+
      '<input type="checkbox" class="bchk" style="float:right" data-key="'+i.key+'" '+(sel?'checked':'')+' onclick="toggleSel(event,this)"> '+
      '<div class="t">'+esc(i.name)+tag+'<span class="gchip">'+esc(i.genre)+'</span>'+qb+rel+'</div>'+
      '<div class="tbar"><i style="width:'+i.progress+'%"></i></div>'+
      '<div class="s"><span>'+i.done+'/'+i.total+' 章 · '+i.total_words+' 字</span></div>'+act+'</div>';
  }).join('');
  syncBatch();
  el.querySelectorAll('[data-op]').forEach(b=>b.onclick=e=>{
    e.stopPropagation(); const k=b.dataset.key,op=b.dataset.op;
    if(op==='prev')openPreview(k);
    else if(op==='cx')contExtra(k);
    else if(op==='cont')cont(k);
    else if(op==='picktitle')openTitle(k);
    else if(op==='restore')batchOp([k],'restore');
  });
}
function toggleSel(e,chk){e.stopPropagation(); if(chk.checked)L.sel.add(chk.dataset.key);else L.sel.delete(chk.dataset.key); syncBatch();}
function syncBatch(){ const n=L.sel.size; $('libbatch').style.display=n?'flex':'none'; $('libn').textContent='已选 '+n+' 本：'; }
function toggleFav(e,el){e.stopPropagation();
  fetch('/api/library/'+encodeURIComponent(el.dataset.key)+'/favorite',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({on:!el.classList.contains('on')})}).then(()=>loadLibrary());
}
function batchOp(keys,action){
  const label={delete:'🗑 归档',restore:'♻ 恢复',favorite:'★ 收藏'}[action]||action;
  fetch('/api/library/batch',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({keys,action})})
   .then(r=>r.json()).then(j=>{ toast(label+' <b>'+keys.length+'</b> 本成功','ok'); L.sel.clear(); loadLibrary(); });
}
function batchReview(keys){ keys.forEach(k=>fetch('/api/validate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({key:k,mode:'report'})})); L.sel.clear(); loadLibrary(); toast('📝 已对 <b>'+keys.length+'</b> 本后台审稿（见事件流）','ok'); }
function showCompare(a,b){
  fetch('/api/compare?keys='+encodeURIComponent(a)+','+encodeURIComponent(b)).then(r=>r.json()).then(d=>{
    if(!d.items||d.items.length<2)return;
    const row=i=>'<div style="flex:1;min-width:130px"><b>'+esc(i.name)+'</b><br>'+
      '<span class="qbadge '+(i.quality==null?'na':i.passing?'pass':'fail')+'">'+(i.quality==null?'未审':i.quality)+'</span> '+esc(i.genre)+
      '<br>'+i.done+'/'+i.total+' 章 · '+i.total_words+' 字 · '+(i.status_label||'')+'</div>';
    $('cmpbox').innerHTML='<div style="border:1px solid var(--border);border-radius:10px;padding:10px;background:var(--panel);display:flex;gap:14px;flex-wrap:wrap;align-items:center;margin-bottom:8px">'+
      row(d.items[0])+'<div style="font-size:16px;color:var(--accent)">⇄</div>'+row(d.items[1])+
      '<button class="libchip" onclick="$(\'cmpbox\').innerHTML=\'\'">✕ 关闭</button></div>';
  });
}
function syncChips(){ $('libstatus').querySelectorAll('.libchip').forEach(c=>c.classList.toggle('on',c.dataset.st===(L.status||''))); }

// ===== 审查后重写 =====
let RWBRIEF=null, _rwT=0;
async function runRewritePlan(){
  if(!PV_KEY||isBusy('rwplan'))return;
  $('rwbox').innerHTML='<div class="rwcard"><h4>🔁 生成重写方向</h4><span id="rwp_busy" class="rwnote">正在分析 13/14/L1 与最低维度…</span></div>';
  const busy=busyStart('rwplan',$('rwp_busy'),'🔁 分析重写方向（五角色审校 + 定位最低维度）');
  let b;
  try{ b=await (await fetch('/api/rewrite-plan',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({key:PV_KEY})})).json(); }catch(e){busy.stop();$('rwbox').innerHTML='<div class="rwcard"><div class="rwnote" style="color:#f59e0b">⚠️ 加载重写方向失败（'+esc(e.message||e)+'），稍后重试。</div></div>';return;}
  busy.stop();
  if(!b||b.before_total==null){$('rwbox').innerHTML='';return;}
  RWBRIEF=b;
  const chaps=(b.chapters||[]).map(c=>c.chapter);
  $('rwbox').innerHTML='<div class="rwcard"><h4>🔁 审查后重写 · 当前 '+b.before_total+' / 达标线 '+b.pass_line+'（'+(b.pass?'✅ 已达标':'未达标，建议重写')+'）</h4>'+
    '<div class="rwdir"><b>主攻方向：</b>'+(b.global_directions||[]).map(g=>esc((g.split('：')[0]))).join(' / ')+'</div>'+
    '<div class="rwdir"><b>逐章待修：</b>'+(chaps.length?'第 '+chaps.join('、')+' 章':'（无定位到章的高严重度项）')+'</div>'+
    (chaps.length?'<div class="rwchips">'+chaps.map(c=>'<label><input type="checkbox" class="rwchk" value="'+c+'" checked> 第'+c+'章</label>').join('')+'</div>':'')+
    '<button class="rwbtn" id="rwgo">开始定向重写（逐条带入要求）</button></div>';
  $('rwgo').onclick=()=>{ const sel=[...document.querySelectorAll('.rwchk')].filter(c=>c.checked).map(c=>+c.value); doRewrite(sel.length?sel:null); };
}
function doRewrite(chapters){
  const g=$('rwgo'); if(g){g.disabled=true;g.textContent='重写中…';}
  _rwT=Date.now();
  fetch('/api/rewrite',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({key:PV_KEY,chapters})})
   .then(r=>r.json()).then(()=>pollRewrite());
}
function pollRewrite(){
  const t=setInterval(async()=>{
    try{
      const d=await (await fetch('/api/rewrite-log?key='+encodeURIComponent(PV_KEY))).json();
      if(!d.running){
        clearInterval(t);
        if(d.result&&d.result.error){ $('rwbox').innerHTML='<div class="rwcard"><h4>⚠️ 重写失败</h4><div class="rwnote">'+esc(d.result.error)+'</div></div>'; }
        else if(d.result){ showRewriteResult(d.result); loadLibrary(); }
        else { $('rwbox').innerHTML='<div class="rwcard"><div class="rwnote">重写完成（无返回结果，见 16-重写记录）。<button class="rwbtn" onclick="showPv(\'quality\')">查看质量报告</button></div></div>'; }
        const g=$('rwgo'); if(g){g.disabled=false;g.textContent='开始定向重写';}
      }
      else if(Date.now()-_rwT>360000){ clearInterval(t); $('rwbox').innerHTML+='<div class="rwnote">重写进行中（>6 分钟，仍在后台跑，可稍后查看 16-重写记录）</div>'; }
    }catch(e){}
  },6000);
}
// ===== v0.7 R2：重写工作台（选章+选维 → 逐章实时进度板 → 取消 → 结果）=====
let _rwBoardPoll=null, _rwKey=null;
async function openRewriteWorkbench(key, preChapters){
  _rwKey=key; $('rwname').textContent='🔁 重写工作台';
  $('rwboard').style.display='none'; $('rwresult').style.display='none';
  $('rwsetup').style.display=''; $('rwgo_row').style.display='flex';
  $('rwchapters').innerHTML='<span id="rwb_busy" class="rwnote">正在分析重写方向…</span>';
  $('rwdims').innerHTML=''; $('rwctx').textContent='';
  if(isBusy('rwplan'))return;
  const busy=busyStart('rwplan',$('rwb_busy'),'🔁 分析重写方向（读 13/14/L1 + 最低维度）');
  let b;
  try{ b=await (await fetch('/api/rewrite-plan',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({key})})).json(); }
  catch(e){ busy.stop(); $('rwchapters').innerHTML='<span class="rwnote" style="color:#f59e0b">⚠️ 加载重写方向失败（'+esc(e.message||e)+'），稍后重试</span>'; return; }
  busy.stop();
  if(!b||b.before_total==null){ $('rwchapters').innerHTML='<span class="rwnote">（该书暂无可分析内容）</span>'; }
  const planCh=(b.chapters&&b.chapters.length)?b.chapters.map(c=>c.chapter):[];
  const dims=(b.weak_dims||[]).map(d=>d.dim);
  const cands=[...new Set([...(preChapters||[]), ...planCh])];          // 可选章节（预选 ∪ 计划待修）
  const selDef=(preChapters===null)?[]:((preChapters&&preChapters.length)?preChapters:planCh);  // 默认勾：预选>计划；null=全书(不勾)
  $('rwchapters').innerHTML=(cands.length?cands:(selDef.length?selDef:[])).map(c=>
    '<label class="rwpick"><input type="checkbox" class="rwch" value="'+c+'" '+((selDef.includes(c))?'checked':'')+'> 第'+c+'章</label>').join('')
    || '<span class="rwnote">（无定位到章的待修项 · 全不勾 = 触发时传 null=重写全书弱章）</span>';
  $('rwdims').innerHTML=(dims.length?dims:[]).map(d=>
    '<label class="rwpick"><input type="checkbox" class="rwdm" value="'+esc(d)+'" checked> '+esc(d)+'</label>').join('')
    || '<span class="rwnote">（不选维度 = 按审查结论全维度主攻）</span>';
  $('rwctx').innerHTML='当前 <b>'+b.before_total+'</b> / 达标线 <b>'+b.pass_line+'</b>（'+(b.pass?'✅已达标':'未达标')+'）· 主攻方向：'+(b.global_directions||[]).map(g=>esc(g.split('：')[0])).join(' / ');
  $('rwmodal').classList.add('show');
  $('rwgo2').onclick=()=>{
    const selCh=[...document.querySelectorAll('.rwch:checked')].map(c=>+c.value);
    const selDims=[...document.querySelectorAll('.rwdm:checked')].map(c=>c.value);
    startRwWorkbench(key, selCh.length?selCh:null, selDims.length?selDims:null);
  };
}
function startRwWorkbench(key, chapters, dims){
  _rwKey=key;
  // v0.8.0：弹窗只是「确认」——点「开始」立即关弹窗、自动回对话页；重写在对话里逐章直播（可切别的书）
  $('rwmodal').classList.remove('show');
  fetch('/api/rewrite',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({key,chapters,dims})}).then(r=>r.json()).then(j=>{ if(j.error) toast(j.error,'err'); });
  if(key===(curSession||curKey)){ switchView('chat'); } else { selectBook(key); }   // 跳到「被重写这本书」的对话页
  rwDialogueLive(key, chapters, dims);   // 对话里放一条「重写进行中」live 气泡，完成后变结果卡（两个按钮已修好）
}
function pollRwProgress(key){
  if(_rwBoardPoll)clearInterval(_rwBoardPoll);
  const t0=Date.now();
  _rwBoardPoll=setInterval(async()=>{
    let p; try{ p=await (await fetch('/api/rewrite-progress?key='+encodeURIComponent(key))).json(); }catch(e){return;}
    if(!p)return;
    renderRwProgress(p,(Date.now()-t0)/1000);
    if(!p.running && p.result){ clearInterval(_rwBoardPoll); _rwBoardPoll=null; showRwResult(p.result,key); }
    else if(p.cancelled){ clearInterval(_rwBoardPoll); _rwBoardPoll=null; $('rwboard_head').innerHTML='⏹ 已取消（已写章保留）'; }
  },1500);
}
function renderRwProgress(p,elapsed){
  const rows=p.per_chapter||[]; const total=p.total||rows.length; const done=p.done||0;
  const pct=total?Math.round(done/total*100):0;
  $('rwbar_fill').style.width=pct+'%';
  $('rwboard_head').innerHTML=(p.running?'🔁 重写进行中':'✅ 重写完成')+'（'+done+'/'+total+' 章 · 已用 '+Math.round(elapsed)+'s'+(p.cancelled?' · 已取消':'')+'）';
  $('rwrows').innerHTML=rows.map(r=>{
    const rev=(r.status==='reverted');
    const st=rev?'🔒 保留原稿':(r.status==='done'?'✔ 完成':(r.status==='skipped'?'⏭ 跳过':(r.status==='rewriting'?'◐ 改写中':'⏸ 排队')));
    const color=rev?'#f5a524':(r.status==='done'?'#3ad29b':(r.status==='rewriting'?'var(--accent)':'var(--muted)'));
    const sc=rev
      ? ' <b style="color:#f5a524">'+(r.before!=null?r.before:'?')+' → '+((r.note||'').replace(/[^\d<>. ]/g,'')||'')+'</b>'
      :((r.after!=null&&r.before!=null)?' <b style="color:'+(r.after>=r.before?'#3ad29b':'#f5a524')+'">'+r.before+' → '+r.after+'</b>':(r.before!=null?' <span style="opacity:.7">基线 '+r.before+'</span>':''));
    return '<div style="font:11px var(--sans);color:var(--text);border:1px solid var(--border);border-radius:8px;padding:5px 8px;background:var(--card);margin-bottom:3px"><b>第'+r.ch+'章</b>'+sc+(r.new_words!=null?' · '+r.orig_words+'→'+r.new_words+' 字':'')+' <span style="float:right;color:'+color+';font-weight:700">'+st+'</span></div>';
  }).join('')||'<div class="rwnote">（进行中）</div>';
}
function cancelRw(key){ fetch('/api/rewrite-cancel',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({key})}).then(r=>r.json()).then(j=>toast(j.msg||'已请求取消（下一检查点停）','ok')); }
function showRwResult(res,key){
  if(res.cancelled){ $('rwboard_head').innerHTML='⏹ 已取消（已写章保留）'; loadManuscript(key); return; }
  if(res.error){ $('rwresult').innerHTML='<div class="rwcard" style="border-color:#f59e0b"><h4>⚠️ 重写失败</h4><div class="rwnote">'+esc(res.error)+'</div></div>'; $('rwresult').style.display=''; return; }
  $('rwresult').innerHTML=renderRewriteResultCard(res,key);
  $('rwresult').style.display=''; $('rwboard').style.display='none';
  loadManuscript(key); loadLibrary();
  bubble('bot','✅ 定向重写完成：'+res.before+' → '+res.after+'（改 '+((res.changed||[]).length)+' 章）','');
}
window.openRewriteWorkbench=openRewriteWorkbench; window.cancelRw=cancelRw;

// ===== v0.8.0：对话内「重写直播」气泡 —— 重写进行中逐章实时、可切别的书；完成变结果卡（两个按钮已修） =====
let _rwDlgPoll={};   // key → interval（对话区重写 live 轮询，按书隔离）
function _rwDlgBubble(key){
  let el=document.querySelector('#msgs .rwbub[data-rwk="'+key+'"]');
  if(el)return el;
  const d=document.createElement('div');
  d.className='msg rwmsg rwbub'; d.setAttribute('data-rwk',key);
  d.innerHTML='<div class="ava">🔁</div><div class="bubble"><div class="chhead"><span class="chttl">🔁 定向重写</span><span class="chstat"></span></div><div class="rwbody"></div></div>';
  msgBox.appendChild(d); return d;
}
function _stopRwDlg(key){ if(_rwDlgPoll[key]){clearInterval(_rwDlgPoll[key]);delete _rwDlgPoll[key];} }
function _startRwDlg(key){ if(_rwDlgPoll[key])return; _rwDlgPoll[key]=setInterval(async()=>{
  try{
    const p=await (await fetch('/api/rewrite-progress?key='+encodeURIComponent(key))).json();   // live 逐章进度
    if(key!==(curSession||curKey))return;
    if(p.running){ _rwDlgPaint(key,{running:true,progress:{done:p.done,total:p.total},per_chapter:p.per_chapter||[]}); return; }
    _stopRwDlg(key);
    const lg=await (await fetch('/api/rewrite-log?key='+encodeURIComponent(key))).json();     // 最终结果卡
    if(key!==(curSession||curKey))return;
    _rwDlgPaint(key,{running:false,result:lg.result,cancelled:(lg.result&&lg.result.cancelled)});
  }catch(e){}
},1500); }
function _rwDlgPaint(key, d){
  const el=_rwDlgBubble(key); const stat=el.querySelector('.chstat'), body=el.querySelector('.rwbody');
  if(d.cancelled || (d.result&&d.result.cancelled)){ stat.textContent='⏹ 已取消（已写章保留）'; body.innerHTML='<div class="rwnote">取消后已写章节保留，可再次发起重写。</div>'; _stopRwDlg(key); const m=msgBox;m.scrollTop=m.scrollHeight; return; }
  if(!d.running && d.result){ stat.innerHTML=''; body.innerHTML=renderRewriteResultCard(d.result, key); _stopRwDlg(key); const m=msgBox;m.scrollTop=m.scrollHeight; return; }
  if(d.running){
    const p=d.progress||{}; const done=p.done||0, total=p.total||0, pct=total?Math.round(done/total*100):0;
    const rows=(d.per_chapter||p.per_chapter||[]);
    stat.innerHTML='<span style="color:var(--accent);font-weight:600">✍️ 重写中 '+(total?done+'/'+total+' · '+pct+'%':'进行中')+'</span>';
    let h='<div class="rwnote" style="margin-bottom:6px">后台逐章改写（保留更好守护）。你现在可以<b>切别的书</b>继续，改完回来这里看进度 + 结果。</div>';
    if(rows.length) h+=rows.map(r=>{ const st=r.status==='reverted'?'🔒保留原稿':(r.status==='done'?'✔ 完成':(r.status==='rewriting'?'◐ 改写中':'⏸ 排队'));
      const sc=(r.after!=null&&r.before!=null)?' <b style="color:'+(r.after>=r.before?'#3ad29b':'#f5a524')+'">'+r.before+'→'+r.after+'</b>':'';
      return '<div style="font:11px var(--sans);color:var(--text);padding:3px 7px;border:1px solid var(--border);border-radius:6px;margin-bottom:3px;background:var(--card)"><b>第'+r.ch+'章</b>'+sc+' <span style="float:right;color:var(--muted)">'+st+'</span></div>'; }).join('');
    body.innerHTML=h; _startRwDlg(key);
    const m=msgBox; m.scrollTop=m.scrollHeight;
  }
}
// 触发重写后：对话里立即放 live 气泡（逐章实时）
function rwDialogueLive(key, chapters, dims){
  bubble('bot','🔁 已开始重写 '+((chapters&&chapters.length)?('第 '+chapters.join('、')+' 章'):'全书弱章')+(dims&&dims.length?(' · '+dims.join(' / ')):' · 全维度')
    +' —— 弹窗已关，重写在对话里进行；你可以<b>切别的书</b>继续，改完回来这里看进度 + 结果（查看质量报告 / 刷新评分）。','');
  _rwDlgBubble(key); _rwDlgPaint(key,{running:true,progress:{done:0,total:(chapters?chapters.length:0)},per_chapter:[]}); _startRwDlg(key);
}
// 切到这本书时：恢复重写气泡（进行中→live 逐章；已完成→结果卡；取消→提示）
function rwDialogueCheck(key){ (async()=>{
  try{
    const p=await (await fetch('/api/rewrite-progress?key='+encodeURIComponent(key))).json();
    if(key!==(curSession||curKey))return;
    if(p.running){ _rwDlgPaint(key,{running:true,progress:{done:p.done,total:p.total},per_chapter:p.per_chapter||[]}); _startRwDlg(key); return; }
    const lg=await (await fetch('/api/rewrite-log?key='+encodeURIComponent(key))).json();
    if(key!==(curSession||curKey))return;
    if(lg.result||lg.cancelled)_rwDlgPaint(key,{running:false,result:lg.result,cancelled:(lg.result&&lg.result.cancelled)});
  }catch(e){}
})(); }
window.rwDialogueLive=rwDialogueLive; window.rwDialogueCheck=rwDialogueCheck;

// ===== v0.7 R4：对话区「本书在干什么」live 卡（Hermes 式 live 步骤，按书隔离+代际守卫）=====
let _blPoll=null;
function startBookLive(key){
  stopBookLive();
  const tk=_viewToken;
  $('booklive').style.display='';
  $('booklive').innerHTML='<div style="font:12px var(--sans);color:var(--muted);padding:5px 2px">📖 载入本书活动…</div>';
  const load=async()=>{
    let d; try{ d=await (await fetch('/api/book-live?key='+encodeURIComponent(key))).json(); }catch(e){return;}
    if(tk!==_viewToken||d.error)return;   // v0.6 A：切书代际守卫
    renderBookLive(d);
  };
  load();
  _blPoll=setInterval(load,1500);
}
function stopBookLive(){ if(_blPoll){clearInterval(_blPoll);_blPoll=null;} $('booklive').style.display='none'; }
function renderBookLive(d){
  const ph={one_shot:'✨ 一键完稿中',parallel:'⚡ 并行创作中',rewriting:'🔁 定向重写中',releasing:'🔓 校验/放行中',writing:'✍️ 创作中',done:'✅ 已成书',failed:'⚠️ 失败',idle:'💤 未运行'}[d.phase]||d.phase;
  const ic={one_shot:'✨',parallel:'⚡',rewriting:'🔁',releasing:'🔓',writing:'✍️',done:'✅',failed:'⚠️',idle:'💤'}[d.phase]||'📖';
  const p=d.progress||{}; const pct=p.pct||0;
  const cur=d.current_chapter?('正在处理 <b>第 '+d.current_chapter+' 章</b>'):'';
  const log=(d.live_log||[]).slice(-4).map(l=>'<div style="opacity:.72">'+esc(l)+'</div>').join('');
  $('booklive').innerHTML=
    '<div style="border:1px solid var(--border);border-radius:11px;background:var(--card);backdrop-filter:var(--glass-blur);box-shadow:var(--glass-shadow);padding:8px 11px;font:12px var(--sans);color:var(--text);margin:0 16px 8px">'+
      '<div style="display:flex;align-items:center;gap:8px;margin-bottom:6px;flex-wrap:wrap">'+
        '<b style="color:var(--text)">'+ic+' '+esc(d.name||'本书')+'</b>'+
        '<span style="color:'+(d.running?'var(--accent)':'var(--muted)')+';font-size:11px">'+ph+'</span>'+
        (cur?'<span style="color:var(--accent);font-size:11px">· '+cur+'</span>':'')+
        (d.paused?'<span style="color:#f59e0b;font-size:11px">· ⏸已暂停</span>':'')+
      '</div>'+
      '<div style="height:6px;background:var(--panel2);border:1px solid var(--border);border-radius:4px;overflow:hidden;margin-bottom:5px"><div style="height:100%;width:'+pct+'%;background:var(--grad-accent);transition:width .5s"></div></div>'+
      '<div style="font-size:10.5px;color:var(--muted);margin-bottom:'+(log?5:0)+'px">'+(p.done||0)+' / '+(p.total||0)+' 章 · '+pct+'%</div>'+
      (log?'<div style="font-size:10.5px;color:var(--muted);border-top:1px dashed var(--border);padding-top:4px;line-height:1.6">'+log+'</div>':'')+
    '</div>';
}
window.startBookLive=startBookLive; window.stopBookLive=stopBookLive;

// v0.6 D：重写结果卡（预览 rwbox 与稿件 msrw 共用；内容=预览「定向重写」同款）
function renderRewriteResultCard(res, key){
  if(res&&res.error) return '<div class="rwcard" style="border-color:#f59e0b"><h4>⚠️ 重写失败</h4><div class="rwnote">'+esc(res.error)+'</div></div>';
  if(!res) return '<div class="rwcard"><div class="rwnote">重写完成（无返回结果，见 16-重写记录.md）。</div></div>';
  const delta=res.after-res.before, up=delta>=0;
  const weak=(res.weak_after&&res.weak_after.length)?res.weak_after.join(' / '):'（无明显短板）';
  return '<div class="rwcard"><h4>🔁 定向重写完成</h4>'
    +'<div class="rwsum">百分制 <b>'+res.before+'</b> → <b style="color:'+(up?'#3ad29b':'#f59e0b')+'">'+res.after+'</b>（<span class="'+(up?'up':'dn')+'">'+(up?'+':'')+delta+'</span>）· '+(res.pass?'✅ 已达标':'未达标')+' · 改写 '+(res.changed||[]).length+' 章</div>'
    +'<div class="rwdir"><b>仍弱维度：</b>'+weak+'</div>'
    +'<div class="rwnote">各章注入的要求 + 前后字数见 <b>16-重写记录.md</b>（作品目录内）。分数为 LLM 五角色重评，可能有波动。</div>'
    +'<div style="margin-top:8px;display:flex;gap:8px;flex-wrap:wrap"><button class="rwbtn" onclick="viewQualityReport(\''+esc(key)+'\')">📊 查看新质量报告</button><button class="rwbtn" onclick="refreshMsScore(\''+esc(key)+'\')">📈 刷新稿件评分</button></div></div>';
}
window.renderRewriteResultCard=renderRewriteResultCard;
// v0.8.0：重写结果卡两个按钮——按「被重写的那本书」定位（此前误用全局 PV_KEY → 别的书/空 就点不动）
function viewQualityReport(key){ if(!key)return; openPreview(key,'quality'); }         // 打开该书预览并定位质量报告页
function refreshMsScore(key){ if(!key)return; loadManuscript(key); switchView('ms'); }  // 刷新该书稿件评分 + 切到稿件视图
window.viewQualityReport=viewQualityReport; window.refreshMsScore=refreshMsScore;
function showRewriteResult(res){
  $('rwbox').innerHTML=renderRewriteResultCard(res, PV_KEY);
}
window.pick=k=>{curKey=k;startPolling();refreshProjects();};
window.cont=k=>{
  fetch('/api/continue',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({key:k})})
    .then(r=>r.json()).then(j=>{bubble('bot',fmt(j.msg||'继续中…'));curKey=k;startPolling();refreshProjects();});
};
window.contExtra=k=>{
  const r=prompt('续写：在现有章节之后继续写几章？','3'); if(r===null)return;
  const extra=Math.max(0,parseInt(r)||0); if(!extra)return;
  fetch('/api/continue',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({key:k,extra:extra})})
    .then(x=>x.json()).then(j=>{bubble('bot',fmt(j.msg||'续写中…'));curKey=k;startPolling();refreshProjects();});
};
// ============ 模型供应商（多供应商绑定 / 创作选模型） ============
let provOpts=[], provPresets=[], provOpen={}, provGroupOpen=null;
const $p=id=>document.getElementById(id);

async function loadProviderPicker(){
  try{
    const j=await (await fetch('/api/model_options')).json();
    provOpts=j.options||[];
    const ps=$p('pselect'), ms=$p('mselect');
    if(!provOpts.length){ps.disabled=ms.disabled=true; ms.innerHTML=''; $p('pvhint').textContent='无可用供应商'; return;}
    ps.disabled=ms.disabled=false;
    ps.innerHTML=provOpts.map(o=>'<option value="'+o.id+'">'+esc(o.name)+'</option>').join('');
    const saved=localStorage.getItem('nbot_prov')||'';
    let defId=(saved&&provOpts.find(x=>x.id===saved))?saved:(j.default_provider||provOpts[0].id);
    ps.value=defId;
    fillModelSel(ps.value);
    ps.onchange=()=>{fillModelSel(ps.value); localStorage.setItem('nbot_prov',ps.value); updateHint();};
    ms.onchange=()=>{localStorage.setItem('nbot_prov',ps.value); updateHint();};
    updateHint();
  }catch(e){}
}
function fillModelSel(pid){
  const o=provOpts.find(x=>x.id===pid), ms=$p('mselect');
  const models=(o&&o.models&&o.models.length)?o.models:[];
  ms.disabled=!models.length;
  ms.innerHTML=models.map(m=>'<option value="'+esc(m)+'">'+esc(m)+'</option>').join('');
  if(o&&o.default_model&&models.includes(o.default_model))ms.value=o.default_model;
  else if(ms.value&&!models.includes(ms.value))ms.value=models[0]||'';
}
function updateHint(){
  const pid=$p('pselect').value, m=$p('mselect').value, o=provOpts.find(x=>x.id===pid);
  $p('pvhint').textContent=(pid&&m)?('当前：'+(o?o.name:pid)+' · '+m):(pid?'当前：'+(o?o.name:pid)+'（默认模型）':'默认供应商');
}

async function loadProviders(){
  try{
    const j=await (await fetch('/api/providers')).json();
    provPresets=j.presets||[];
    const list=j.providers||[], defId=j.default_provider, el=$p('provlist'), sum=$p('provsum');
    if(!list.length){
      sum.style.display='none';
      el.style.display='block';
      el.innerHTML='<div class="empty">尚未绑定供应商<br><button class="vbtn" style="margin-top:8px" onclick="openProvModal()">＋ 绑定一个</button></div>';
      return;
    }
    // 组级折叠：多个自动收起（重叠），单个自动展开；用户可点击切换
    if(provGroupOpen===null) provGroupOpen=(list.length>1)?false:true;
    const defName=(list.find(x=>x.id===defId)||{}).name||'（无）';
    sum.style.display='flex';
    sum.innerHTML='<span class="arr">▶</span><span class="vdot"></span><b>模型供应商</b><span class="sumn">'+list.length+' 个 · 默认 '+esc(defName)+'</span>';
    sum.classList.toggle('open', provGroupOpen);
    sum.onclick=toggleProvGroup;
    el.style.display=provGroupOpen?'block':'none';
    el.innerHTML=list.map(p=>{
      const isDef=p.id===defId, curm=p.default_model;
      const bodyOpen=(provOpen[p.id]!==undefined)?provOpen[p.id]:(!isDef); // 默认供应商收起，其它展开
      const mlist=(p.models&&p.models.length)
        ? '<div class="vmodels">'+p.models.map(m=>'<span class="mtag'+(m===curm?' cur':'')+'" data-m="'+esc(m)+'" data-pid="'+p.id+'" title="点我设为该供应商默认">'+esc(m)+(m===curm?' ✓':'')+'</span>').join('')+'</div>'+
          '<div class="vmodels-hint">点任一模型 → 设为该供应商的默认模型</div>'
        : '<div class="vmodels">（无模型清单 · 点「拉取模型」或绑定表单填写）</div>';
      return '<div class="vitem'+(p.active?'':' off')+(bodyOpen?'':' collapsed')+'" data-id="'+p.id+'">'+
        '<div class="vh" data-toggle="'+p.id+'"><span class="vchev">▾</span><span class="vdot"></span>'+
        '<span class="vname">'+esc(p.name)+(isDef?' <span class="vdef">★ 默认</span>':'')+'</span>'+
        '<span class="vstat">'+(p.active?'可用':'停用')+'</span></div>'+
        '<div class="vbody">'+
          '<div class="vrow">'+
            '<button class="vbtn" data-act="toggle" data-id="'+p.id+'">'+(p.active?'停用':'启用')+'</button>'+
            '<button class="vbtn def" data-act="def" data-id="'+p.id+'"'+(isDef?' disabled':'')+'>'+(isDef?'默认':'设默认')+'</button>'+
            '<button class="vbtn" data-act="test" data-id="'+p.id+'">测试</button>'+
            '<button class="vbtn" data-act="fetch" data-id="'+p.id+'">拉取模型</button>'+
            '<button class="vbtn danger" data-act="del" data-id="'+p.id+'">删除</button>'+
          '</div>'+
          mlist+
          '<div class="vkey">key：'+esc(p.key_display||'未设置')+'</div>'+
          '<div class="vstat vtest" style="margin-top:5px"></div>'+
        '</div>'+
      '</div>';
    }).join('');
    el.querySelectorAll('[data-toggle]').forEach(h=>h.onclick=e=>{e.stopPropagation();toggleVitem(h.dataset.toggle);});
    el.querySelectorAll('.mtag[data-m]').forEach(t=>t.onclick=e=>{e.stopPropagation();setProvDefaultModel(t.dataset.pid,t.dataset.m);});
    el.querySelectorAll('[data-act]').forEach(b=>b.onclick=()=>provAction(b.dataset.act,b.dataset.id,b));
  }catch(e){}
}
function toggleProvGroup(){ provGroupOpen=!provGroupOpen; const s=$p('provsum'); s.classList.toggle('open',provGroupOpen); $p('provlist').style.display=provGroupOpen?'block':'none'; }
function toggleVitem(pid){ const el=document.querySelector('.vitem[data-id="'+pid+'"]'); if(!el)return; const c=el.classList.toggle('collapsed'); provOpen[pid]=!c; }
async function setProvDefaultModel(pid, model){
  const r=await fetch('/api/providers/'+encodeURIComponent(pid),{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({default_model:model})});
  const j=await r.json(); if(j.error){bubble('bot','⚠️ 设置默认模型失败：'+j.error);return;}
  await loadProviders(); await loadProviderPicker();
  bubble('bot','✅ 「'+(j.provider.name)+'」的默认模型已设为 <b>'+esc(model)+'</b>。');
}
async function provAction(act, pid, btn){
  try{
    if(act==='del'){
      if(!confirm('删除供应商「'+pid+'」？（其数据与模型清单将一并移除）'))return;
      const j=await (await fetch('/api/providers/'+encodeURIComponent(pid),{method:'DELETE'})).json();
      if(j.error)throw new Error(j.error);
    }else if(act==='def'){
      await fetch('/api/providers/'+encodeURIComponent(pid)+'/default',{method:'POST'});
    }else if(act==='toggle'){
      const wantActive=btn.textContent.trim()==='启用';
      await fetch('/api/providers/'+encodeURIComponent(pid)+'/active',{method:'POST',
        headers:{'Content-Type':'application/json'},body:JSON.stringify({active:wantActive})});
    }else if(act==='test'){
      if(btn){btn.classList.add('busy');btn.textContent='测试中…';}
      const j=await (await fetch('/api/providers/'+encodeURIComponent(pid)+'/test',{method:'POST',
        headers:{'Content-Type':'application/json'},body:'{}'})).json();
      const box=document.querySelector('.vitem[data-id="'+pid+'"] .vtest');
      if(box)box.textContent=(j.ok?'✅ ':'⚠️ ')+(j.detail||'');
      if(btn){btn.classList.remove('busy');btn.textContent='测试';}
      if(j.models&&j.models.length)return loadProviders();
      return;
    }else if(act==='fetch'){
      if(btn){btn.classList.add('busy');btn.textContent='拉取中…';}
      const j=await (await fetch('/api/providers/'+encodeURIComponent(pid)+'/models',{method:'POST'})).json();
      const box=document.querySelector('.vitem[data-id="'+pid+'"] .vtest');
      if(box)box.textContent=j.from_api?('✅ 已拉取 '+j.models.length+' 个模型'):('⚠️ '+(j.msg||'拉取失败'));
      if(btn){btn.classList.remove('busy');btn.textContent='拉取模型';}
    }
    await loadProviders(); await loadProviderPicker();
  }catch(e){bubble('bot','⚠️ 供应商操作失败：'+e);}
}

function openProvModal(){
  $p('merr').textContent='';
  const ps=$p('mpreset');
  ps.innerHTML='<option value="">自定义</option>'+provPresets.map(p=>'<option value="'+p.slug+'">'+esc(p.name)+'</option>').join('');
  ps.onchange=presetChg();
  $p('mname').value='';$p('murl').value='';$p('mkey').value='';$p('mkeyfile').value='';$p('mmodels').value='';
  $p('mtemp').value='0.85';$p('mtoken').value='12000';$p('mtimeout').value='900';$p('mactive').checked=true;
  $p('provmodal').classList.add('show');
}
function presetChg(){
  return function(){
    const s=$p('mpreset').value, p=provPresets.find(x=>x.slug===s); $p('merr').textContent='';
    if(p){$p('mname').value=p.name;$p('murl').value=p.base_url;$p('mkeyfile').value='';
      $p('mmodels').value=(p.models||[]).join(', ');}
  };
}
function closeProvModal(){$p('provmodal').classList.remove('show');}
async function bindProv(){
  $p('merr').textContent='';
  const preset=$p('mpreset').value;
  const payload={name:$p('mname').value.trim(), base_url:$p('murl').value.trim(),
    api_key:$p('mkey').value.trim(), api_key_file:$p('mkeyfile').value.trim(),
    models:$p('mmodels').value.split(/[,\n]/).map(s=>s.trim()).filter(Boolean),
    temperature:parseFloat($p('mtemp').value)||0.85,
    max_tokens:parseInt($p('mtoken').value)||12000,
    timeout:parseInt($p('mtimeout').value)||900,
    active:$p('mactive').checked};
  if(preset)payload.preset=preset;
  if(!payload.base_url&&!preset){$p('merr').textContent='请选择预设或填写 Base URL';return;}
  if(!preset&&!payload.models.length){$p('merr').textContent='请填写至少一个模型（逗号分隔），或选预设自动填充';return;}
  const j=await (await fetch('/api/providers',{method:'POST',
    headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)})).json();
  if(j.error){$p('merr').textContent=j.error;return;}
  closeProvModal();
  await loadProviders(); await loadProviderPicker();
  bubble('bot','✅ 已绑定供应商「'+(j.provider.name)+'」（'+(j.provider.models.length||0)+' 个模型）。创作时可在输入框上方选择供应商与模型。');
}
window.openProvModal=openProvModal;
window.closeProvModal=closeProvModal;

// ============ 作品预览（点开即看内容） ============
let PV_KEY=null, PV_TEXT='';
function mdLite(s){
  let t=esc(s||'');
  t=t.replace(/^#{1,6}\s+(.+)$/gm,(m,x)=>'<div class="pv-h">'+x+'</div>');
  t=t.replace(/^>\s?(.+)$/gm,(m,x)=>'<div class="pv-q">'+x+'</div>');
  t=t.replace(/^[ \t]*[-*]\s+(.+)$/gm,(m,x)=>'<div class="pv-li">• '+x+'</div>');
  t=t.replace(/^[ \t]*[-=]{3,}[ \t]*$/gm,'<div class="pv-hr"></div>');
  t=t.replace(/\*\*(.+?)\*\*/g,'<b>$1</b>');
  t=t.replace(/\n{3,}/g,'\n\n').replace(/\n/g,'<br>');
  t=t.replace(/<\/div><br>/g,'</div>').replace(/<br><div/g,'<div').replace(/<br><br>/g,'<br><br>');
  return t;
}
async function openPreview(key, tab){
  PV_KEY=key; PV_TEXT='';
  $('pvmodal').classList.add('show');
  $('pvtitle').textContent='加载中…'; $('pvbody').textContent='加载中…'; $('pvch').innerHTML='';
  const j=await (await fetch('/api/preview?key='+encodeURIComponent(key))).json();
  if(j.error){$('pvbody').textContent='⚠️ '+j.error;return;}
  PV_TEXT=j.text||'';
  const done=(j.chapters||[]).filter(c=>c.status==='completed').length;
  $('pvtitle').textContent='《'+(j.name||key)+'》 '+(j.has_book?'· 成书':'· 已写 '+done+' 章')
    +(j.total_words?(' · 约 '+j.total_words+' 字'):'');
  $('pvdow').href='/api/download?key='+encodeURIComponent(key);
  const haveCh=(j.chapters||[]).filter(c=>(c.words||0)>0||c.status==='completed');
  const sel=$('pvch');
  sel.innerHTML='<option value="all">'+(j.has_book?'全文（成书）':'全部已写')+'</option>'+
    haveCh.map(c=>'<option value="'+c.n+'">第'+c.n+'章'+(c.continuation?'（续写）':(c.title&&c.title!=='续写'?' '+esc(c.title):''))+'</option>').join('')
    +(j.has_book?'<option value="quality">📊 质量报告（五角色+达标判定）</option><option value="review">📋 修订记录（五角色审校）</option>':'');
  sel.onchange=()=>showPv(sel.value);
  if(tab && [...sel.options].some(o=>o.value===tab)) sel.value=tab;
  showPv(tab||'all');   // v0.8.0：支持直接定位到某页（如重写后「查看新质量报告」→ quality）
}
async function showPv(sel){
  const body=$('pvbody');
  if(sel==='all'){ body.innerHTML=mdLite(PV_TEXT)||'<span style="color:var(--muted)">（暂无内容）</span>'; }
  else if(sel==='quality'){
    const j=await (await fetch('/api/quality?key='+encodeURIComponent(PV_KEY))).json();
    body.innerHTML=(j&&j.text)?mdLite(j.text):'<span style="color:var(--muted)">尚未质检。点右上「📝 审稿」跑 确定性引擎+五角色 并出百分制达标判定。</span>';
  }
  else if(sel==='review'){
    const j=await (await fetch('/api/review?key='+encodeURIComponent(PV_KEY))).json();
    body.innerHTML=(j&&j.text)?mdLite(j.text):'<span style="color:var(--muted)">尚未审稿。点右上「📝 审稿」跑一次五角色分层编辑。</span>';
  }
  else{
    const j=await (await fetch('/api/chapter?key='+encodeURIComponent(PV_KEY)+'&n='+sel)).json();
    body.innerHTML=mdLite(j.text||'（该章尚未生成）');
  }
  body.scrollTop=0;
}
async function runValidate(){
  if(!PV_KEY) return;
  const b=$('pvval'); b.disabled=true; b.textContent='⏳ 审稿中';
  $('pvbody').textContent='📝 正在跑 确定性引擎 + 五角色审校 + 百分制（对标达标线 90），约 30-90 秒…';
  await fetch('/api/validate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({key:PV_KEY,mode:'report'})});
  const t0=Date.now();
  const poll=async()=>{
    try{
      const s=await (await fetch('/api/status?key='+encodeURIComponent(PV_KEY))).json();
      if(s.state==='completed'||s.state==='failed'||s.state==='idle'){
        await showPv('quality'); $('pvch').value='quality'; b.disabled=false; b.textContent='📝 审稿'; return;
      }
      if(Date.now()-t0<180000) setTimeout(poll,4000);
      else {b.disabled=false;b.textContent='📝 审稿';}
    }catch(e){b.disabled=false;b.textContent='📝 审稿';}
  };
  setTimeout(poll,3000);
}
window.openPreview=openPreview;
window.closePvModal=()=>$('pvmodal').classList.remove('show');
window.runValidate=runValidate;

// ===== 开书向导 + 书名 ABC + 放行门禁 =====
let ONB=null, TMKEY=null, TMCANDS=[];
// v0.8.1 新建一本书：先回「默认对话」，开书向导变成「可选」入口——
//   ① 按向导：点「🧙 开向导」定题材/篇幅/风格/卖点 → submitOnb 建书；
//   ② 直接说：在输入框说你要的 → sendMsg 自动判断匹配开书；取消向导就留在对话里。
function newBookFlow(){ switchView('chat'); newBookLauncherCard(); setTimeout(()=>{try{$('inp').focus();}catch(e){}},50); }
function newBookLauncherCard(){
  const old=$('newlauncher'); if(old)old.remove();
  const b=addMsg('bot'); b.id='newlauncher';
  const bb=b.querySelector('.bubble');
  bb.innerHTML=
    '<div style="font:600 13px var(--sans);color:var(--text);margin-bottom:6px">🧙 开书向导（可选）</div>'+
    '<div style="font:12px/1.95 var(--sans);color:var(--muted)">两种开书方式：<br>'+
    '① <b style="color:var(--text)">按向导</b>：点「🧙 开向导」，定题材 / 篇幅 / 风格 / 卖点；<br>'+
    '② <b style="color:var(--text)">直接说</b>：在下方输入框写你要的（如「都市悬疑 · 退休刑警翻盘，50章」），我自动判断匹配开书。<br>'+
    '<span style="opacity:.7">取消向导就留在这个对话里直接打字即可。</span></div>'+
    '<button class="pb" style="margin-top:9px" onclick="openOnb()">🧙 开书向导</button>';
  msgBox.scrollTop=msgBox.scrollHeight;
}
async function openOnb(){
  $('onbmodal').classList.add('show');
  if(!ONB){ try{ ONB=await (await fetch('/api/onboarding')).json(); }catch(e){ ONB={genres:['都市爽文'],tones:['爽文'],sells:['打脸','逆袭'],perspectives:['男主','女主','不限'],chapter_options:[10],defaults:{release_gate:true,p5_pipeline:true}}; } }
  const sel=(id,vals,def)=>{const el=$(id);el.innerHTML=vals.map(v=>'<option value="'+esc(v)+'">'+esc(v)+'</option>').join('');if(def)el.value=def;};
  sel('ob_genre',ONB.genres,ONB.genres[0]); sel('ob_persp',ONB.perspectives,'男主');
  sel('ob_tone',ONB.tones,'爽文'); sel('ob_chap',(ONB.chapter_options||[3,5,10,20,50]).concat('自定义'),10);
  $('ob_chap').onchange=()=>{$('ob_chap_custom').style.display=($('ob_chap').value==='自定义')?'block':'none';};
  $('ob_chap_custom').value='';
  // v0.3 P2 风格技能（金手指/节奏/语言，按题材 preset 自动填，可改）
  const _sty=ONB.style||{}, _prev=($('ob_genre').value)||ONB.genres[0], _pre=( _sty.preset||{})[_prev]||{};
  sel('ob_hand',_sty['金手指']||[],_pre['金手指']||(_sty['金手指']||[])[0]);
  sel('ob_pace',_sty['节奏']||[],_pre['节奏']||(_sty['节奏']||[])[0]);
  sel('ob_lang',_sty['语言']||[],_pre['语言']||(_sty['语言']||[])[0]);
  $('ob_genre').onchange=()=>{const p=(_sty.preset||{})[$('ob_genre').value]||{};
    if(p['金手指'])$('ob_hand').value=p['金手指']; if(p['节奏'])$('ob_pace').value=p['节奏']; if(p['语言'])$('ob_lang').value=p['语言'];
    const pn=$('obprefnote');if(pn)pn.style.display='none';};
  fillOnbStyle(); prefillFromLearn();
  $('ob_sells').innerHTML=ONB.sells.map(s=>'<span class="libchip" data-v="'+esc(s)+'" style="cursor:pointer">'+esc(s)+'</span>').join('');
  $('ob_sells').querySelectorAll('.libchip').forEach(c=>c.onclick=()=>c.classList.toggle('on'));
  try{
    const mo=await (await fetch('/api/model_options')).json();
    $('ob_prov').innerHTML=(mo.options||[]).map(o=>'<option value="'+o.id+'">'+esc(o.name)+'</option>').join('');
    fillOnbModel(); $('ob_prov').onchange=fillOnbModel;
  }catch(e){ $('ob_prov').innerHTML='<option value="">默认</option>'; }
  $('ob_gate').checked=ONB.defaults?.release_gate!==false;
  $('ob_p5').checked=ONB.defaults?.p5_pipeline!==false;
}
function fillOnbModel(){
  const pid=$('ob_prov').value;
  fetch('/api/model_options').then(r=>r.json()).then(mo=>{
    const o=(mo.options||[]).find(x=>x.id===pid); const ms=o?o.models||[]:[];
    $('ob_model').innerHTML=ms.map(m=>'<option value="'+esc(m)+'">'+esc(m)+'</option>').join('')||'<option value="">默认</option>';
    if(o?.default_model) $('ob_model').value=o.default_model;
  }).catch(()=>{});
}
window.closeOnb=()=>$('onbmodal').classList.remove('show');
async function submitOnb(){
  const sells=[...$('ob_sells').querySelectorAll('.libchip.on')].map(c=>c.dataset.v);
  let _chap=+$('ob_chap').value;
  if($('ob_chap').value==='自定义'){ _chap=+$('ob_chap_custom').value; if(!(_chap>=1&&_chap<=200)){$('oberr').textContent='⚠️ 自定义章节数需在 1-200 之间';return;} }
  const payload={genre:$('ob_genre').value, tone:$('ob_tone').value, perspective:$('ob_persp').value,
    style:{金手指:$('ob_hand').value, 节奏:$('ob_pace').value, 语言:$('ob_lang').value, 卷:(_chap<=10?'单卷(10章)':'多卷(3卷各10)')},
    sells, idea:$('ob_idea').value.trim(), total_chapters:_chap,
    provider_id:$('ob_prov').value, model:$('ob_model').value,
    style_id:($('ob_style').value==='__none'?'':$('ob_style').value)||'',
    cfg_overrides:{defaults:{release_gate:$('ob_gate').checked, p5_pipeline:$('ob_p5').checked}}};
  if($('ob_title').value.trim()) payload.title=$('ob_title').value.trim();
  if(isBusy('create'))return;                       // 防双击/连点（本地模型慢时尤易误点）
  const busy=busyStart('create',$('oberr'),'📐 规划中（选题→人物→大纲→细纲 + 生成 8 个候选书名）',$('obgo'));
  let r;
  try{ r=await (await fetch('/api/create',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)})).json(); }
  catch(e){ busy.stop(); $('oberr').textContent='⚠️ '+(e.message||e)+'——开书超时/失败（本地模型响应慢或网络中断）。可稍后重试，或在供应商里换成 Agnes 公网再开；'+($('oberr').textContent?'':''); return; }
  if(r.error){ busy.stop(); $('oberr').textContent='⚠️ '+r.error; return; }
  busy.stop();
  closeOnb(); refreshProjects();
  if(r.awaiting_title){ openTitle(r.key); }
  else { curKey=r.key; curSession=r.key; startPolling(); bubble('bot','📐 《'+payload.title+'》开写中（放行门禁 '+(payload.cfg_overrides.defaults.release_gate?'开':'关')+'）…对话里逐章直播 👇'); switchView('chat'); }
}
$('obgo').onclick=submitOnb;
window.openOnb=openOnb;
// ===== v0.3.4 学习进化：报告 + 按偏好预填 =====
async function loadLearn(){
  const el=$('learnreport');if(!el)return;
  let p;try{p=await (await fetch('/api/learn')).json();}catch(e){el.innerHTML='<div class="empty">加载失败</div>';return;}
  const g=p.genres||[];
  el.innerHTML=(p.total?'<div class="rwnote" style="margin-bottom:8px;font-size:11px">'+esc(p.insight||('已学习 '+p.total+' 本'))+'</div>':'')
    +(g.length?'<div style="display:flex;flex-direction:column;gap:7px">'+g.slice(0,6).map(x=>{
      const bar='<div style="display:flex;align-items:center;gap:8px;font:11px var(--sans)"><span style="width:56px;overflow:hidden;text-overflow:ellipsis;color:var(--muted)">'+esc(x.genre)+'</span>'
        +'<span style="flex:1;height:6px;background:var(--panel2);border-radius:4px;overflow:hidden"><span style="display:block;height:100%;width:'+(x.share||0)+'%;background:linear-gradient(90deg,#7c5cff,#3ad29b)"></span></span>'
        +'<span style="color:var(--muted);width:30px;text-align:right">'+x.count+'本</span></div>';
      const pf=[];if(x.top_hand&&x.top_hand[0])pf.push(x.top_hand[0]);if(x.top_pace&&x.top_pace[0])pf.push(x.top_pace[0]);if(x.top_lang&&x.top_lang[0])pf.push(x.top_lang[0]);
      return '<div>'+bar+(pf.length?'<div style="font:10px var(--muted);margin:2px 0 0 56px">偏好：'+esc(pf.join(' · '))+'</div>':'')+'</div>';
    }).join('')+'</div>':'<div class="empty">还没写过小说。写几本后，系统会自动学习你的题材与偏好，下次开书按偏好预填。</div>');
}
window.loadLearn=loadLearn;
async function prefillFromLearn(){
  let p;try{p=await (await fetch('/api/learn')).json();}catch(e){return;}
  const g=(p.genres||[]).find(x=>x.genre===$('ob_genre').value);
  if(!g)return;
  let changed=false;
  if(g.top_hand&&g.top_hand[0]){ $('ob_hand').value=g.top_hand[0]; changed=true; }
  if(g.top_pace&&g.top_pace[0]){ $('ob_pace').value=g.top_pace[0]; changed=true; }
  if(g.top_lang&&g.top_lang[0]){ $('ob_lang').value=g.top_lang[0]; changed=true; }
  const n=$('obprefnote'); if(n){ n.style.display=changed?'block':'none'; n.textContent='📈 已按你「'+g.genre+'」的偏好预填（金手指/节奏/语言）'; }
  if(changed&&window.cxApplyAll)cxApplyAll();
}
window.prefillFromLearn=prefillFromLearn;
async function fillOnbStyle(){
  const names=[];try{names=(await (await fetch('/api/styles')).json()).items.map(x=>x.name);}catch(e){}
  const el=$('ob_style');
  el.innerHTML='<option value="__none">（不用蒸馏风格）</option>'+names.map(n=>'<option value="'+esc(n)+'">✨ '+esc(n)+'</option>').join('');
  el.value='__none';
}
window.fillOnbStyle=fillOnbStyle;
async function loadStyleLib(){
  const el=$('stylelib');if(!el)return;
  let items=[];try{items=(await (await fetch('/api/styles')).json()).items;}catch(e){el.innerHTML='<div class="empty">加载失败</div>';return;}
  el.innerHTML=items.length?(''):'<div class="empty">暂无蒸馏风格。点「＋ 蒸馏新风格」把一段小说/网址蒸馏成可复用的专属风格。</div>';
  items.forEach(s=>{
    const c=document.createElement('div');
    c.style.cssText='border:1px solid var(--border);background:var(--panel2);border-radius:11px;padding:9px 11px;margin-bottom:8px';
    c.innerHTML='<div style="font:600 13px var(--sans);color:var(--text)">✨ '+esc(s.name)+(s.genre?' <span style="font:10px var(--muted);font-weight:400">· '+esc(s.genre)+'</span>':'')+'</div>'
      +'<div style="font:11px var(--muted);line-height:1.5;margin-top:3px">'+esc(s.summary||'')+'</div>'
      +(s.fingerprint_words&&s.fingerprint_words.length?'<div style="font:10.5px var(--muted);margin-top:4px">指纹词：'+esc(s.fingerprint_words.slice(0,6).join(' · '))+'</div>':'')
      +'<div style="margin-top:7px"><button class="pb" style="font-size:10.5px;padding:3px 8px" onclick="delStyle(\''+esc(s.name)+'\')">🗑 删除</button></div>';
    el.append(c);
  });
}
window.loadStyleLib=loadStyleLib;
function delStyle(name){ if(!confirm('删除风格「'+name+'」？（开过的新书不受影响）'))return; fetch('/api/styles/'+encodeURIComponent(name),{method:'DELETE'}).then(r=>r.json()).then(j=>{toast(j.ok?'已删除风格':'删除失败','ok');loadStyleLib();}); }
window.delStyle=delStyle;
function openDistill(){ ['dl_name','dl_genre','dl_text','dl_urls'].forEach(id=>{const e=$(id);if(e)e.value='';}); $('dlerr').textContent=''; $('distillmodal').classList.add('show'); }
window.openDistill=openDistill;
window.closeDistill=()=>$('distillmodal').classList.remove('show');
// ===== v0.4 放行弹窗：待放行书 → 直接解决 =====
var _rlKey=null;
async function openReleaseModal(key){
  _rlKey=key; const b=$('rlbody'); b.innerHTML='<div class="rwnote">加载放行信息…</div>'; $('rlerr').textContent='';
  $('releasemodal').classList.add('show');
  let lib={}; try{ const d=await (await fetch('/api/library')).json(); lib=d.items.find(x=>x.key===key)||{}; }catch(e){}
  let log={}; try{ log=await (await fetch('/api/release-log?key='+encodeURIComponent(key))).json(); }catch(e){}
  const q=(lib.final_quality!=null?lib.final_quality:(lib.quality!=null?lib.quality:null));
  const pl=lib.pass_line||90;
  let rows=''; ((log.result&&log.result.gate_results)||[]).slice(0,6).forEach(g=>{ rows+='<div style="font:11px var(--muted)">第'+(g.round||'')+'轮：'+(g.before||0)+' → '+(g.after||0)+(g.stopped?'（达标停）':'')+'</div>'; });
  // v0.5 M1/M2：逐章评分表（<90 高亮，可点章重写）
  let pv={}; try{ pv=await (await fetch('/api/preview?key='+encodeURIComponent(key))).json(); }catch(e){}
  const pcs=pv.per_chapter||[], pl2=pv.pass_line||pl;
  const belowCh=pcs.filter(x=>x.score!=null&&x.score<pl2);
  let chart='';
  if(pcs.length){
    chart='<div style="margin-top:8px;border-top:1px solid var(--border);padding-top:6px">'+
      '<div style="font:11px var(--muted);margin-bottom:5px">📊 逐章评分（线 '+pl2+'）'+(belowCh.length?' · <b style="color:#f59e0b">'+belowCh.length+' 章未达标</b>':' · 全部达标 ✅')+'</div>'+
      '<div style="display:flex;gap:5px;flex-wrap:wrap">'+pcs.map(x=>{
        const bad=x.score!=null&&x.score<pl2;
        return '<span data-rlch="'+x.ch+'" style="cursor:pointer;padding:2px 7px;border-radius:8px;font:11px;border:1px solid '+(bad?'#f59e0b':'var(--border)')+';background:'+(bad?'rgba(245,158,11,.15)':'transparent')+';color:'+(bad?'#f59e0b':'var(--text)')+';font-weight:'+(bad?'700':'400')+'">第'+x.ch+'章 '+(x.score!=null?x.score:'—')+(bad?' ⚠️':'')+'</span>';
      }).join('')+'</div>'+
      (belowCh.length?'<div style="margin-top:5px;font:11px var(--muted)">点章节 = 单章重写 · 下方「重写未达标」= 多选重写 '+belowCh.length+' 章</div>':'')+'</div>';
  }
  b.innerHTML='📖 <b>'+esc(lib.name||key)+'</b><br>'
    +'当前成书质量：<b style="color:'+(q!=null&&q>=pl?'#3ad29b':'#f59e0b')+'">'+(q!=null?q:'未评分')+'</b> / 放行线 '+pl
    +(q!=null?(q>=pl?'（已达标，可放行 ✅）':'（未达线，放行将标 beta）'):'')
    +'<br>'+(lib.gate_rounds?('已跑 '+lib.gate_rounds+' 轮门禁'):'')+(rows?('<div style="margin-top:4px">'+rows+'</div>'):'')
    +chart
    +'<br><span style="font:11px var(--muted)">🔓放行=定稿成书 · 🔁重写并看稿件=带要求重写并进工作台看书写 · 再校验=重跑门禁提分</span>';
  // 逐章点击=单章重写
  [...document.querySelectorAll('[data-rlch]')].forEach(el=>{ el.onclick=()=>{ releaseRewrite(key,[+el.dataset.rlch]); }; });
  $('rl_go').onclick=()=>{ fetch('/api/release',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({key})}).then(x=>x.json()).then(j=>{ toast('🔓 '+(j.msg||'放行中')+'（完成会弹通知）','ok'); closeRelease(); renderSessions(); startPolling(); }); };
  // v0.5 M2：重写并看稿件（延续预览里的重写功能，直接进入该书工作台）
  $('rl_rw').onclick=()=>{ releaseRewrite(key, belowCh.length?belowCh.map(x=>x.ch):null); };
  $('rl_again').onclick=()=>{ fetch('/api/validate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({key,mode:'report'})}).then(x=>x.json()).then(j=>{ toast('🔁 再校验中（' + (j.msg||'') + '）','ok'); closeRelease(); startPolling(); }); };
  $('rl_beta').onclick=()=>{ toast('保持 beta（先留着不改）','ok'); closeRelease(); };
}
window.openReleaseModal=openReleaseModal;
window.closeRelease=()=>$('releasemodal').classList.remove('show');
async function submitDistill(){
  const name=$('dl_name').value.trim(), genre=$('dl_genre').value.trim();
  const text=$('dl_text').value.trim(), urls=$('dl_urls').value.split('\n').map(s=>s.trim()).filter(Boolean);
  if(!name){ $('dlerr').textContent='⚠️ 请给风格起个名字'; return; }
  if(!text && !urls.length){ $('dlerr').textContent='⚠️ 请粘贴文本或填网址（至少一样）'; return; }
  if(isBusy('distill'))return;
  const busy=busyStart('distill',$('dlerr'),'✨ 蒸馏中（抽取 7 维写作 DNA + 生成指纹词）',$('dlgo'));
  let j;
  try{ j=await (await fetch('/api/distill',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name,genre,text,urls})})).json(); }
  catch(e){ busy.stop(); $('dlerr').textContent='⚠️ '+(e.message||e)+'（蒸馏超时/失败，可重试）'; return; }
  if(!j.ok){ busy.stop(); $('dlerr').textContent='⚠️ '+(j.note||j.error||'蒸馏失败'); return; }
  busy.stop();
  $('dlerr').textContent=''; closeDistill(); toast('✨ 已蒸馏风格「'+name+'」（'+(j.style?.fingerprint_words?.length||0)+' 指纹词）','ok');
  loadStyleLib(); fillOnbStyle();
}
window.submitDistill=submitDistill;
(function(){ const b=$('btn-distill'); if(b)b.onclick=openDistill; const g=$('dlgo'); if(g)g.onclick=submitDistill; })();

async function openTitle(key){
  TMKEY=key; $('titlemodal').classList.add('show');
  $('tmcards').innerHTML='<div class="rwnote"><span id="tm_busy">生成候选书名中…</span></div>';
  if(isBusy('titles'))return;
  const busy=busyStart('titles',$('tm_busy'),'✍️ 生成 8 个候选书名');
  let d;
  try{ d=await (await fetch('/api/titles?key='+encodeURIComponent(key))).json(); }catch(e){ busy.stop(); $('tmcards').innerHTML='<div class="rwnote" style="color:#f59e0b">⚠️ 加载失败（'+esc(e.message||e)+'），稍后重试</div>'; return; }
  busy.stop();
  TMCANDS=d.candidates||[]; $('tmcustom').value='';
  const L='ABCDEFGHIJ';
  $('tmcards').innerHTML=(TMCANDS.length?TMCANDS:[{title:'未命名'}]).map((c,i)=>
    '<label class="tmcard" data-t="'+esc(c.title||'')+'" style="display:flex;gap:10px;align-items:center;border:1px solid var(--border);border-radius:10px;padding:9px 12px;cursor:pointer;background:var(--panel)">'+
      '<span style="font-size:15px;font-weight:700;color:var(--accent);width:18px">'+L[i]+'</span>'+
      '<div style="flex:1"><b>'+esc(c.title||'（未命名）')+'</b><div style="font-size:11px;color:var(--muted)">'+esc((c.technique||'')+' · '+(c.why||''))+'</div></div></label>').join('');
  $('tmcards').querySelectorAll('.tmcard').forEach(l=>l.onclick=()=>{
    $('tmcards').querySelectorAll('.tmcard').forEach(x=>{x.style.borderColor='var(--border)';x.style.background='var(--panel)';});
    l.style.borderColor='var(--accent)'; l.style.background='rgba(108,140,255,.12)'; $('tmcustom').value=l.dataset.t;
  });
  $('tmgoto').onclick=()=>{ const t=$('tmcustom').value.trim(); if(!t)return; doPickTitle(TMKEY,t); };
}
async function doPickTitle(key,title){
  closeTitle();
  let r; try{ r=await (await fetch('/api/pick-title',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({key,title})})).json(); }
  catch(e){ toast('⚠️ 选名失败：'+e,'err'); return; }
  if(r.ok){ curKey=r.key; curSession=r.key; startPolling(); loadLibrary(); toast('📐 《<b>'+esc(title)+'</b>》开写中…','ok'); switchView('chat'); }
  else toast('⚠️ 选名失败：'+(r.error||''),'err');
}
window.openTitle=openTitle; window.closeTitle=()=>$('titlemodal').classList.remove('show');

async function runReleaseGate(){
  if(!PV_KEY)return;
  $('gatebox').innerHTML='<div class="rwcard"><h4>🔓 放行门禁</h4><div class="rwnote">自动带要求重写到 ≥90（约 2-6 分钟）…</div>'+
    '<button class="gcancel" onclick="cancelGate()">✕ 取消门禁</button></div>';
  await fetch('/api/release',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({key:PV_KEY})});
  const t=setInterval(async()=>{
    try{
      const d=await (await fetch('/api/release-log?key='+encodeURIComponent(PV_KEY))).json();
      if(!d.running){ clearInterval(t); showGate(d); loadLibrary(); }
    }catch(e){}
  },6000);
}
function cancelGate(){
  if(!PV_KEY)return;
  fetch('/api/release-cancel',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({key:PV_KEY})})
   .then(()=>toast('⏹️ 已请求取消放行门禁','err'));
}
function showGate(d){
  const r=d.result||{};
  $('gatebox').innerHTML='<div class="rwcard"><h4>🔓 放行门禁结果</h4>'+
    '<div class="rwsum">'+(r.before??'—')+' → '+(r.after??'—')+' · 达标线 '+(r.pass_line||90)+' · '+(r.released?'✅ 已放行（可出书）':'⚠️ 未放行（beta）')+'</div>'+
    '<div class="rwnote" style="white-space:pre-wrap">'+esc((d.gate||'').replace(/##\s/g,''))+'</div></div>';
}
window.runReleaseGate=runReleaseGate;

// ===== 作品库工具条 绑定 =====
(function(){
  const sort=$('libsort'), ord=$('liborder');
  sort.onchange=()=>{ L.sort=sort.value; L.order=(L.sort==='quality'||L.sort==='genre')?'asc':'desc'; ord.textContent=L.order==='desc'?'↓':'↑'; loadLibrary(); };
  ord.onclick=()=>{ L.order=L.order==='desc'?'asc':'desc'; ord.textContent=L.order==='desc'?'↓':'↑'; loadLibrary(); };
  let qT=null; $('libq').oninput=e=>{ L.q=e.target.value; clearTimeout(qT); qT=setTimeout(loadLibrary,250); };
  $('libstatus').querySelectorAll('.libchip').forEach(c=>c.onclick=()=>{ L.status=c.dataset.st; L.genre=''; syncChips(); loadLibrary(); });
  $('libbatch').querySelectorAll('[data-batch]').forEach(b=>b.onclick=()=>{
    const act=b.dataset.batch, keys=[...L.sel];
    if(act==='clear'){ L.sel.clear(); loadLibrary(); }
    else if(act==='review'){ batchReview(keys); }
    else if(act==='compare'){ if(keys.length>=2) showCompare(keys[0], keys[1]); }
    else { batchOp(keys, act); }
  });
})();
bindModalClose();

// ===== v0.3 三栏工作台：会话=书 / 该书对话 / 产物·设置·作品库 =====
const S_pins=(()=>{try{return JSON.parse(localStorage.nbot_pins)||[]}catch(e){return[]}})();
let curSession=null; let _LIB_ITEMS=[];   // v0.3.3：左侧「⋯」菜单 用（缓存当前书列表）
let _viewToken=0;   // v0.6 A：视图代际——切书 +1，丢弃旧书慢响应对当前视图的覆盖（防跨书串台）
function sideTab(name){['art','set','lib'].forEach(t=>$('pane-'+t).style.display=t===name?'block':'none');document.querySelectorAll('.side-tabs button').forEach(b=>b.classList.toggle('on',b.dataset.tab===name));if(name==='set'){if(window.loadModelRules)loadModelRules();if(window.loadStyleLib)loadStyleLib();if(window.loadLearn)loadLearn();if(window.renderAgentCard)renderAgentCard();}if(name==='lib'&&window.loadGlobalToken)loadGlobalToken();}
window.sideTab=sideTab;
function _sessRow(i){
  const st=i.state==='completed'?(i.released===true?'released':'completed'):(i.awaiting_title?'awaiting_title':(i.running?'in_progress':'other'));
  const qm=i.quality!=null?(' · '+i.quality+(i.released===false?'未放行':'')):'';
  const live=sessLive(i);
  return '<div class="ss-item'+(curSession===i.key?' on':'')+'" data-key="'+i.key+'">'
    +'<span class="ss-dot '+st+'"></span>'
    +'<div class="ss-main"><div class="ss-name">'+(S_pins.includes(i.key)?'📌 ':'')+esc(i.name)+'</div>'
    +'<div class="ss-meta">'+esc(i.genre||'—')+' · '+i.done+'/'+i.total+' 章'+(live?' · <span style="color:var(--accent);font-weight:600">'+live+'</span>':'')+qm+(i.schedule?' · ⏱':'')+'</div></div>'
    +'<span class="ss-act" data-menu="'+i.key+'" title="操作">⋯</span></div>';
}
// v0.3.5：左侧书行实时状态（正在写第X章 / 校验第N轮 / 待选书名 …）
function sessLive(i){
  if(i.awaiting_title)return '⏸ 待选书名';
  if(i.paused)return '⏸ 已暂停 · 第 '+(i.total?Math.min(i.done+1,i.total):((i.done||0)+1))+' 章';
  if(i.halted)return '⚠ 已中断 · 可续写（点该书 / ⋯ 菜单）';
  if(i.state==='in_progress')return '✍️ 正在写第 '+(i.total?Math.min(i.done+1,i.total):(i.done||0)+1)+' 章';
  if(i.state==='validating'||i.state==='releasing')return '🔁 校验/放行'+(i.gate_rounds?' 第 '+i.gate_rounds+' 轮':'中');
  if(i.state==='completed')return i.released===false?('⏳ 待放行 · 点击放行'+(i.gate_rounds?'（'+i.gate_rounds+'轮）':'')):'✅ 已成书';
  if(i.state==='failed')return '⚠ 失败 · 可重试';
  return '✍ 创作中';
}
window.sessLive=sessLive;
function renderSessions(){
  fetch('/api/library?sort=updated&order=desc').then(r=>r.json()).then(d=>{
    if(!d.items)return;
    _LIB_ITEMS=d.items; window._libCache=d.items; updateSendBtn();
    const autoArch=localStorage.nbot_autoarch!=='0';
    const active=d.items.filter(i=>!i.archived&&i.state!=='archived');
    const isDone=i=>autoArch&&i.state==='completed'&&i.released===true;
    const pinned=active.filter(i=>S_pins.includes(i.key)).sort((a,b)=>S_pins.indexOf(a.key)-S_pins.indexOf(b.key));
    const doing=active.filter(i=>!isDone(i)&&!S_pins.includes(i.key));
    const done=active.filter(isDone);
    // 「我的书」（进行中）
    const ga=$('grpbody-a'); let h='';
    if(pinned.length)h+='<div class="sgrp">📌 置顶</div>'+pinned.map(_sessRow).join('');
    h+='<div class="sgrp">进行中</div>'+(doing.length?doing.map(_sessRow).join(''):'<div class="snew" style="border:none;background:none;color:var(--muted);cursor:default"><span class="txt">暂无 · 点上方「＋新建」</span></div>');
    if(ga)ga.innerHTML=h;
    // 「已归档」
    const gd=$('grpbody-d'), arch=$('slarch');
    if(done.length){ if(gd)gd.innerHTML=done.map(_sessRow).join(''); if(arch)arch.style.display=''; }
    else { if(gd)gd.innerHTML=''; if(arch)arch.style.display='none'; }
    // 分组头（计数 + chevron）
    const slc=$('slcount'); if(slc)slc.innerHTML='📚 我的书 <span class="cnt">'+active.length+'</span><span class="chev">▾</span>';
    if(arch)arch.innerHTML='✅ 已归档 <span class="cnt">'+done.length+'</span><span class="chev">▾</span>';
    applyGrpState();
    const bind=el=>{ el.onclick=()=>{ const it=_LIB_ITEMS.find(x=>x.key===el.dataset.key);
      if(it&&it.state==='completed'&&it.released===false&&!it.archived){ openReleaseModal(el.dataset.key); }
      selectBook(el.dataset.key); };
      const m=el.querySelector('[data-menu]');if(m)m.onclick=e=>{e.stopPropagation();openBookMenu(el.dataset.key,m);}; };
    (ga?ga.querySelectorAll('.ss-item'):[], gd?gd.querySelectorAll('.ss-item'):[]).flatMap(x=>[...x]).forEach(bind);
  }).catch(()=>{});
}
// v0.9.0 左侧分组折叠：点「我的书 / 已归档 / 总览」→ 收起/展开（localStorage 记忆）
function toggleGrp(which){
  const map={a:['slcount','grpbody-a'], d:['slarch','grpbody-d']};
  const [h,b]=map[which]; const hh=$(h), bb=$(b); if(!hh||!bb)return;
  const nowCollapsed=hh.classList.toggle('collapsed');
  bb.style.display=nowCollapsed?'none':'';
  localStorage['nbot_grp_'+which]=nowCollapsed?'1':'0';
}
function applyGrpState(){
  [['slcount','grpbody-a','a'],['slarch','grpbody-d','d']].forEach(([h,b,w])=>{
    const hh=$(h),bb=$(b); if(!hh||!bb)return;
    const col=localStorage['nbot_grp_'+w]==='1';
    hh.classList.toggle('collapsed',col); bb.style.display=col?'none':'';
  });
}
window.renderSessions=renderSessions; window.toggleGrp=toggleGrp;
function togglePin(key){const i=S_pins.indexOf(key);if(i>=0)S_pins.splice(i,1);else S_pins.unshift(key);localStorage.nbot_pins=JSON.stringify(S_pins);renderSessions();}
window.togglePin=togglePin;
// v0.3.3：左侧「⋯」小菜单（仿 Hermes 会话三点）——置顶/归档/改名/下载/续写/彻底删除，按书状态动态
let _bkPanel=null,_bkAnchor=null;
function _bkClose(){ if(_bkPanel)_bkPanel.style.display='none'; }
function openBookMenu(key, anchor){
  const it=_LIB_ITEMS.find(x=>x.key===key)||{key,state:'other',archived:false,name:'?'};
  if(!_bkPanel){
    _bkPanel=document.createElement('div');
    _bkPanel.style.cssText='display:none;position:fixed;z-index:999;background:#141830;border:1px solid var(--border);border-radius:11px;box-shadow:0 12px 34px rgba(0,0,0,.55);min-width:178px;padding:5px';
    document.body.append(_bkPanel);
    document.addEventListener('click',e=>{ if(_bkPanel&&_bkAnchor&&_bkAnchor.contains(e.target))return; if(_bkPanel.contains(e.target))return; _bkClose(); });
    document.addEventListener('keydown',e=>{ if(e.key==='Escape')_bkClose(); });
  }
  _bkAnchor=anchor;
  const pinned=S_pins.includes(key), st=it.state||'other';
  const canBook=['completed','released','validating'].includes(st);
  const canCont=['completed','in_progress','validating'].includes(st);
  const items=[];
  items.push(['📌 '+(pinned?'取消置顶':'置顶'),()=>{togglePin(key);_bkClose();renderSessions();}]);
  items.push([(it.archived?'♻️ 恢复归档':'🗄 归档'),()=>{fetch('/api/library/'+encodeURIComponent(key)+'/archive',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({on:!it.archived})}).then(r=>r.json()).then(()=>{toast(it.archived?'已恢复':'已移入回收站','ok');_bkClose();renderSessions();});}]);
  // v0.4：随时控（像 Agent 聊天）：暂停/继续/续写剩余/放行/即时指令 —— 不留死路
  if(it.state==='in_progress'&&!it.paused)items.push(['⏸ 暂停（停在当前进度）',()=>{fetch('/api/pause',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({key})}).then(x=>x.json()).then(j=>{toast(j.msg||'已暂停','ok');_bkClose();renderSessions();startPolling();});}]);
  if(it.paused)items.push(['▶ 继续写作',()=>{fetch('/api/resume',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({key})}).then(x=>x.json()).then(j=>{toast(j.msg||'继续中','ok');_bkClose();renderSessions();curSession=key;startPolling();switchView('ms');});}]);
  if(it.state==='in_progress')items.push(['▶ 续写剩余全部',()=>{fetch('/api/continue',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({key})}).then(x=>x.json()).then(j=>{toast(j.msg||'续写中','ok');_bkClose();renderSessions();curSession=key;startPolling();switchView('ms');});}]);
  if(it.state==='completed'&&it.released===false)items.push(['🔓 放行成书（解决待放行）',()=>{openReleaseModal(key);_bkClose();}]);
  items.push(['📝 加即时修正指令',()=>{const t=prompt('给这本书加一条创作指令（写作中可随时改剧情/细节）：');if(t&&t.trim()){const imm=confirm('点「确定」=立即生效（下一章立刻用）；「取消」=排队到下一条。');fetch('/api/queue',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({key,text:t.trim(),immediate:imm})}).then(x=>x.json()).then(j=>{toast(j.ok?('指令已加入，'+(j.items.length||0)+' 条待处理'):'加入失败','ok');renderSessions();})}_bkClose();}]);
  items.push(['✏️ 重命名',()=>{const nn=prompt('新书名：',it.name||'');if(nn&&nn.trim()){fetch('/api/library/'+encodeURIComponent(key)+'/rename',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:nn.trim()})}).then(r=>r.json()).then(j=>{toast(j.ok?'已改名':(j.note||'改名失败'),j.ok?'ok':'err');renderSessions();});}_bkClose();}]);
  if(canBook)items.push(['⬇ 下载成书',()=>{window.open('/api/download?key='+encodeURIComponent(key),'_blank');_bkClose();}]);
  if(canCont)items.push(['▶ 续写',()=>{const r=prompt('续写：在现有章节后继续写几章？','3');if(r!==null){const n=Math.max(1,+r||1);fetch('/api/continue',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({key,n})}).then(x=>x.json()).then(j=>{bubble('bot',fmt(j.msg||'续写中…'));curKey=key;curSession=key;startPolling();switchView('ms');renderSessions();});}_bkClose();}]);
  items.push(['🗑 彻底删除（不可恢复）',()=>{ if(confirm('彻底删除《'+(it.name||key)+'》？将删除作品目录，不可恢复！')){fetch('/api/library/'+encodeURIComponent(key)+'?hard=true',{method:'DELETE'}).then(r=>r.json()).then(j=>{toast(j.note||'已删除',j.ok?'ok':'err');renderSessions();});} _bkClose(); }]);
  _bkPanel.innerHTML='';
  items.forEach(([label,fn],idx)=>{
    if(label.startsWith('🗑')){const sep=document.createElement('div');sep.style.cssText='height:1px;background:var(--border);margin:4px 6px';_bkPanel.append(sep);}
    const d=document.createElement('div'); d.textContent=label;
    d.style.cssText='padding:8px 11px;font:12.5px var(--sans);color:'+(label.startsWith('🗑')?'var(--err)':'var(--text)')+';cursor:pointer;border-radius:8px;white-space:nowrap';
    d.onmouseenter=()=>d.style.background='rgba(255,255,255,.07)'; d.onmouseleave=()=>d.style.background='';
    d.onclick=e=>{e.stopPropagation();fn();}; _bkPanel.append(d);
  });
  _bkPanel.style.display='block';
  const r=anchor.getBoundingClientRect(), pw=Math.max(178,_bkPanel.offsetWidth);
  _bkPanel.style.width=pw+'px'; _bkPanel.style.left=r.left+'px'; _bkPanel.style.transform='';
  const below=(r.bottom+2+_bkPanel.offsetHeight)<=innerHeight;
  if(below)_bkPanel.style.top=(r.bottom+2)+'px';
  else{ _bkPanel.style.top=(r.top-2)+'px'; _bkPanel.style.transform='translateY(-100%)'; }
}
window.openBookMenu=openBookMenu;
async function selectBook(key){
  curSession=key;curKey=key;_viewToken++;const tk=_viewToken;sideTab('art');renderSessions();updateSendBtn();
  $('msrw').innerHTML='';   // v0.6 D/A：切书清空上一本书的重写结果卡（按书隔离）
  startBookLive(key);       // v0.7 R4：对话区「本书在干什么」live 卡（切书换代际守卫自动切）
  switchView('chat'); loadBkChat(key);   // v0.4.1：点书 → 中间=对话页，只加载这本书自己的聊天
  let st={state:'',done:0,total:0};try{st=await (await fetch('/api/status?key='+encodeURIComponent(key))).json();}catch(e){}
  if(tk!==_viewToken)return;   // v0.6 A：期间切了书，弃旧响应
  let pv={};try{pv=await (await fetch('/api/preview?key='+encodeURIComponent(key))).json();}catch(e){}
  if(tk!==_viewToken)return;
  const name=pv.name||st.name||key;
  const stt=st.awaiting_title?'待选书名':(st.state==='completed'?'已成书':(st.state==='in_progress'?'创作中':(st.state||'')));
  let u={};try{u=(await (await fetch('/api/usage?key='+encodeURIComponent(key))).json()).usage||{};}catch(e){}
  if(tk!==_viewToken)return;
  $('midctx').innerHTML='📖 当前书：<b>'+esc(name)+'</b> · '+esc(stt)+' · <span style="color:var(--accent)">🔢 '+((u.total_tokens||0).toLocaleString())+' token</span> · 对话/操作都针对这本书';
  let qa='<button class="pb run" onclick="oneShot(\''+key+'\')" title="熔炼总架构→写剩余章节→逐章评分→不达标自动重写→放行门禁，全自动（看活动卡）">✨ 一键完稿</button>'
    +'<button class="pb run" onclick="actCont()">▶ 续写</button>'
    +'<button class="pb" onclick="actValidate()">📝 审稿</button>'
    +'<button class="pb" onclick="actGate()">🔓 门禁</button>'
    +'<button class="pb" onclick="toggleStudio()" title="展开/收起顶部『工作室总览』（多书任务看板）">🏆 总览</button>'
    +'<a class="pb prev" href="/api/download?key='+encodeURIComponent(key)+'" target="_blank">⬇ 下载</a>';
  if(st.awaiting_title)qa='<button class="pb run" onclick="openTitle(\''+key+'\')">✍ 选书名</button>'+qa;
  if(st.state==='completed')qa+='<button class="pb" onclick="openPreview(\''+key+'\')">👁 预览</button>';
  qa+='<button class="pb" onclick="parallelWrite()" title="先熔炼总架构，N 个 Agent 分章齐写（写完一个立即取下一章）">⚡ 并行创作</button>'
    +'<button class="pb" onclick="showBlueprint()" title="写前统一的总架构蓝图（世界观/人物/全章节拍/文风/连续性）">🧩 总架构</button>';
  $('quickacts').innerHTML=qa;
  loadSkeleton(key);   // v0.9.0：切书即刷新「🦴 写作骨架」（写到哪/多少/重点/为何/续写提示）
  const rel=pv.released===true?'已放行✅':(pv.released===false?'beta·未放行⚠️':'');
  $('artbody').innerHTML='<div style="font:600 14px var(--sans)">'+esc(name)+'</div>'
    +'<div style="font:11.5px var(--muted);margin:5px 0 9px">'+(pv.total||st.total||0)+' 章 · '+(pv.words||0)+' 字 · '+esc(rel||stt)+'</div>'
    +'<div style="display:flex;gap:6px;flex-wrap:wrap"><button class="pb prev" onclick="openPreview(\''+key+'\')">👁 预览成书</button><button class="pb" onclick="actValidate()">📊 质量报告</button></div>';
  $('setbody').innerHTML=
    '<div style="padding:14px 14px 4px">'
    +'<div class="srow"><span class="sic">🎚</span><div class="sct"><b>放行门禁</b><div class="sdesc">达标线 <b style="color:var(--text)">90</b> · 每轮 top-3 改写 · 未达标标 beta；一键完稿/并行写完后自动过门禁</div></div></div>'
    +'<div class="srow"><span class="sic">⏱</span><div class="sct"><b>定时任务</b><div class="sdesc">默认关 · 可设总章 / 节奏 / 触发</div><div id="booksched" style="margin-top:7px"></div></div></div>'
    +'<div class="srow"><span class="sic">🧩</span><div class="sct"><b>题材 × 风格技能</b><div class="sdesc">绑定 '+esc(pv.genre||st.genre||'未绑定')+' 技能，写前自动注入风格）</div><div id="bookskill" style="margin-top:7px"></div></div></div>'
    +'</div>';
  loadBookSkill(key); loadBookSched(key); loadTokenLedger(key);
  startPolling(); refreshProjects();
  switchView('chat');   // v0.4.1：选中书后默认显示「对话」（只属于这本书的专属聊天）；想看小说正文点「📄稿件」
}
window.selectBook=selectBook;
function actCont(){if(!curSession)return;cont(curSession);startPolling();switchView('ms');}
window.actCont=actCont;
function actValidate(){if(!curSession)return;fetch('/api/validate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({key:curSession,mode:'report'})}).then(async r=>{const j=await r.json();toast('📝 审稿'+(r.ok?'完成':'失败：'+(j.msg||'')),r.ok?'ok':'err');if(r.ok)selectBook(curSession);});}
window.actValidate=actValidate;
function actGate(){if(!curSession)return;fetch('/api/release',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({key:curSession})}).then(r=>r.json()).then(j=>toast('🔓 门禁：'+(j.msg||''),'ok'));}
window.actGate=actGate;
// ===== v0.6 B：并行创作 + 总架构查看 =====
// v0.9.0：点击并行创作 → 弹「派几个子 Agent」选择器（2/3/5/8 + 自定义 1-8），不再写死 5
let _parKey=null, _parPreset=5;
function openParPicker(key){
  _parKey=key||curSession; if(!_parKey)return;
  const P=$('parpicks'); if(!P)return;
  P.innerHTML=[2,3,5,8].map(n=>'<button class="pb" style="padding:7px 15px;font-size:12px;margin:0" data-w="'+n+'">'+n+' 个</button>').join('');
  P.querySelectorAll('[data-w]').forEach(b=>b.onclick=()=>{ $('parpw').value=b.dataset.w; P.querySelectorAll('[data-w]').forEach(x=>x.classList.toggle('on',x===b)); });
  $('parpw').oninput=()=>{ const v=+$('parpw').value; P.querySelectorAll('[data-w]').forEach(x=>x.classList.toggle('on',+x.dataset.w===v)); };
  $('parperr').textContent='';
  const w=localStorage.nbot_parw; if(w) $('parpw').value=w;
  P.querySelectorAll('[data-w]').forEach(x=>x.classList.toggle('on',+x.dataset.w===+$('parpw').value));
  $('parpicker').classList.add('show');
}
function doParallelWrite(key, workers){
  workers=Math.max(1,Math.min(8,workers||_parPreset||3));
  localStorage.nbot_parw=workers;
  switchView('ms'); loadManuscript(key);
  $('msrw').innerHTML='<div class="rwcard" style="border-color:var(--accent)"><h4>⚡ 并行创作中（'+workers+' 个子 Agent）</h4><div class="rwnote">先熔炼『总架构』，'+workers+' 个子 Agent 分章齐写（写完一个立即取下一章）… 完成后此处刷新。</div></div>';
  fetch('/api/parallel-write',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({key,workers:workers})})
   .then(r=>r.json()).then(j=>{bubble('bot','⚡ '+esc(j.msg||('已派出 '+workers+' 个子 Agent 并行创作'))+'（稿件区实时刷新）','');pollParallel(key);})
   .catch(e=>{ $('msrw').innerHTML=''; bubble('bot','⚠️ 并行创作启动失败：'+(e.message||e),'err'); });
}
function parallelWrite(){ openParPicker(curSession); }          // 快捷入口：弹选择器
function parPick(){
  if(!_parKey)return;
  let w=Math.max(1,Math.min(8, +$('parpw').value||_parPreset||3));
  $('parpw').value=w;
  $('parpicker').classList.remove('show');
  doParallelWrite(_parKey, w);
}
window.parallelWrite=parallelWrite; window.openParPicker=openParPicker; window.parPick=parPick;
(function(){ const g=$('parpgo'); if(g)g.onclick=parPick; })();
// ===== v0.7 R5：一键完稿（小白）—— 串引擎全自动，进度看「本书在干什么」活动卡 =====
function oneShot(key){
  key=key||curSession; if(!key)return;
  if(!confirm('✨ 一键完稿这本书？\n将自动串起：熔炼总架构 → 写剩余章节 → 逐章评分 → 不达标自动重写（含「更好才换」守护）→ 放行门禁。\n全程后台跑，看对话区「本书在干什么」活动卡实时进度。\n\n⚠ 会消耗较多 LLM 额度，确认？'))return;
  fetch('/api/one-shot',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({key,auto_rewrite:true,auto_release:true})})
   .then(r=>r.json()).then(j=>{ toast(j.msg||'✨ 一键完稿已启动','ok'); startBookLive(key); switchView('chat'); });
}
window.oneShot=oneShot;
// ===== v0.7 R5：工作室总览（重度）—— 任务看板 mini 进度（多书同看） =====
let _studioPoll=null;
async function studioOverview(){
  const ov=await fetch('/api/studio-overview').then(r=>r.json()).catch(()=>null);
  const el=$('studioview'); if(!el)return; if(!ov){el.style.display='none';return;}
  const books=(ov.books||[]).filter(b=>!b.archived);
  if(!books.length){ el.style.display='none'; return; }
  const run=books.filter(b=>b.running), rest=books.filter(b=>!b.running);
  const list=[...run, ...rest.slice(0, Math.max(0,14-run.length))];   // 运行中置顶，最多14
  const SLB={in_progress:'写稿中',completed:'已完稿',validating:'放行中',releasing:'放行中',failed:'异常'};
  const row=b=>{
    const pct=b.total?Math.round(b.done/b.total*100):0;
    const ic={in_progress:'✍',completed:'✅',validating:'🔓',releasing:'🔓',failed:'⚠️'}[b.state]||'📖';
    const ok=b.quality!=null&&b.quality>=90;
    const chip=b.running?(SLB[b.state]||'运行'):(b.quality!=null?(ok?'达标✅':'分'+b.quality):(SLB[b.state]||'企划'));
    return '<div class="strow'+(b.running?' run':'')+'" onclick="selectBook(\''+b.key+'\')" title="'+esc(b.name||b.key)+'">'+
      '<div class="sr1"><span class="sn">'+(b.running?'⚡ ':'')+ic+' '+esc(b.name||b.key)+'</span>'+
        '<span class="ch'+(ok?' ok':'')+'">'+chip+'</span></div>'+
      '<div class="sbar"><i style="width:'+pct+'%"></i></div>'+
      '<div class="sr2">'+b.done+'/'+b.total+' 章'+(b.quality!=null?(ok?' · 达标':' · 分'+b.quality):'')+'</div></div>';
  };
  el.style.display='';
  const stListOpen=localStorage.nbot_studio_open!=='0';
  el.innerHTML='<div class="sthead" onclick="toggleStudioList()" title="点击 收起/展开"><span>🏆 工作室总览</span><span class="schip">'+(run.length?'<b style="color:var(--accent)">'+run.length+'</b> 运行中':'共 '+books.length+' 本')+'</span><span class="chev" id="studiochev" '+(stListOpen?'':'style="transform:rotate(-90deg)"')+'>▾</span></div>'+
    '<div class="stlist" id="studiolist" '+(stListOpen?'':'style="display:none"')+'>'+list.map(row).join('')+'</div>';
}
function toggleStudioList(){
  const l=$('studiolist'), c=$('studiochev'); if(!l)return;
  const open=l.style.display==='none';
  l.style.display=open?'':'none';
  if(c)c.style.transform=open?'':'rotate(-90deg)';
  localStorage.nbot_studio_open=open?'1':'0';
}
window.toggleStudioList=toggleStudioList;
function startStudio(){ if(!_studioPoll){ studioOverview(); _studioPoll=setInterval(studioOverview,3000);} }
function toggleStudio(){ const el=$('studioview'); if(!el)return; if(el.style.display==='none') startStudio(); else { if(_studioPoll){clearInterval(_studioPoll);_studioPoll=null;} el.style.display='none'; } }
window.startStudio=startStudio; window.toggleStudio=toggleStudio;
// ===== v0.9.0 写作骨架：产物页顶部「🦴 写作骨架」卡（读到哪/多少/重点/为何/续写提示）=====
let _skMd='';
function skRender(md){
  return md.split("\n").map(line=>{
    const t=esc(line);
    if(/^##\s/.test(line))return '<div style="font:700 12.5px var(--sans);color:var(--accent);margin:9px 0 4px">'+line.replace(/^##\s*/,'')+'</div>';
    if(/^>\s?/.test(line))return '<div style="font:11px var(--sans);color:var(--muted);opacity:.85;margin:2px 0">'+t.replace(/^&gt;\s?/,'')+'</div>';
    if(/^[-·]\s/.test(line))return '<div style="padding-left:9px;border-left:2px solid rgba(108,140,255,.35);margin:2px 0;line-height:1.75">'+t.replace(/^[-·]\s/,'').replace(/\*\*(.+?)\*\*/g,'<b>$1</b>')+'</div>';
    if(line.trim()==='')return '';
    return '<div style="line-height:1.75;margin:2px 0">'+t.replace(/\*\*(.+?)\*\*/g,'<b>$1</b>')+'</div>';
  }).join('');
}
async function loadSkeleton(key, regen){
  key=key||curSession; const c=$('skcard'); if(!c)return;
  if(!key){ c.innerHTML='<div class="empty">选中一本书后，这里显示它的总体状态（写到哪 / 多少 / 重点 / 为何 / 续写提示）。写完·重写·放行会自动刷新。</div>'; return; }
  c.innerHTML='<div class="skh">🦴 写作骨架 <span class="skbtns"><button class="pb" style="margin:0;padding:2px 9px" onclick="loadSkeleton(\''+esc(key)+'\',1)">↻ 刷新</button><button class="pb" style="margin:0;padding:2px 9px" onclick="copySkeleton()">⧉ 复制</button></span></div><div class="skb"><div class="empty">加载骨架中…</div></div>';
  try{
    const j=await (await fetch('/api/skeleton?key='+encodeURIComponent(key)+(regen?'&regen=1':''))).json();
    _skMd=j.md||'';
    const has=_skMd.trim();
    c.innerHTML='<div class="skh">🦴 写作骨架 <span class="skbtns"><button class="pb" style="margin:0;padding:2px 9px" onclick="loadSkeleton(\''+esc(key)+'\',1)">↻ 刷新</button><button class="pb" style="margin:0;padding:2px 9px" onclick="copySkeleton()">⧉ 复制</button></span></div>'+
      '<div class="skb">'+(has?skRender(_skMd):'<div class="empty">尚未生成（本书还没写够内容）。点上方「↻ 刷新」立即生成。</div>')+'</div>'+
      '<div class="skfoot">文件 <b style="color:var(--accent)">17-写作骨架.md</b>'+(j.updated?' · 更新 '+esc(j.updated):'')+' · 已自动注入续写 / 改写 Agent 的上下文</div>';
  }catch(e){ c.innerHTML='<div class="skh">🦴 写作骨架</div><div class="skb"><div class="empty">⚠️ 骨架加载失败：'+esc(String(e))+'</div></div>'; }
}
function copySkeleton(){
  if(!_skMd){ toast('暂无骨架可复制','err'); return; }
  navigator.clipboard?.writeText(_skMd).then(()=>toast('📋 写作骨架已复制（可直接粘给 LLM 作总体状态）','ok'),()=>toast('复制失败','err'));
}
window.loadSkeleton=loadSkeleton; window.copySkeleton=copySkeleton;
// ===== v0.7 R5：小白空态 3 步引导（#msgs 空 + 未选书时）=====
function emptyGuide(){
  if(msgBox.children.length>0)return;
  const d=document.createElement('div'); d.className='msg bot'; d.id='empguide';
  d.innerHTML='<div class="ava">🖋</div><div class="bubble" style="max-width:430px">'+
    '<div style="font:600 14px var(--sans);color:var(--text);margin-bottom:6px">👋 三步开一本小说</div>'+
    '<ol style="margin:0;padding-left:18px;font:12.5px/1.9 var(--sans);color:var(--muted)">'+
    '<li><b style="color:var(--text)">① 说个主题</b>：下方输入框打字（如「都市悬疑·退休刑警复仇翻盘」），或点左侧「＋ 新建一本书」。</li>'+
    '<li><b style="color:var(--text)">② 选书看进度</b>：左侧选一本书，对话区「📖 本书在干什么」活动卡实时显示它在写哪一章、进度、日志（Hermes 式）。</li>'+
    '<li><b style="color:var(--text)">③ 一键完稿</b>：选中书后点「✨ 一键完稿」，自动 熔炼总架构→写剩余章→逐章评分→不达标重写→放行，全程看活动卡。</li></ol>'+
    '<div style="margin-top:8px;font:11px var(--sans);color:var(--muted);opacity:.75">小白：直接「✨ 一键完稿」；重度：用 并行创作 / 重写工作台 / 工作室总览 精细控制。</div>'+
    '</div>';
  msgBox.appendChild(d); msgBox.scrollTop=msgBox.scrollHeight;
}
window.emptyGuide=emptyGuide;
let _ppPoll={};
function pollParallel(key){
  if(_ppPoll[key])clearInterval(_ppPoll[key]);
  const t0=Date.now();
  _ppPoll[key]=setInterval(async()=>{
    try{
      const lg=await (await fetch('/api/parallel-log?key='+encodeURIComponent(key))).json();
      const st=await (await fetch('/api/status?key='+encodeURIComponent(key))).json();
      const isCur=(key===(curSession||curKey));   // v0.6 A：只刷当前书
      if(!lg.running){
        clearInterval(_ppPoll[key]);
        if(isCur){
          const done=(st.done||0),tot=(st.total||0);
          const ev=(st.events||[]).slice(-6).map(e=>esc(e)).join('<br>')||'完成';
          $('msrw').innerHTML='<div class="rwcard" style="border-color:#3ad29b"><h4>⚡ 并行创作完成（总架构对齐）· '+done+'/'+tot+' 章</h4><div class="rwnote" style="max-height:180px;overflow:auto">'+ev+'</div><div style="margin-top:8px"><button class="rwbtn" onclick="viewQualityReport(\''+esc(key)+'\')">📊 刷新评分 + 看质量报告</button></div></div>';
          loadManuscript(key);
        }
        loadLibrary();
      } else if(Date.now()-t0>600000){ clearInterval(_ppPoll[key]); }
    }catch(e){}
  },5000);
}
window.pollParallel=pollParallel;
async function showBlueprint(){
  if(!curSession)return;
  const key=curSession;
  const j=await (await fetch('/api/blueprint?key='+encodeURIComponent(key))).json();
  const bp=j.blueprint||{};
  let bodyHtml;
  if(j.md){ bodyHtml='<div style="white-space:pre-wrap;font:12.5px/1.8 var(--sans);color:var(--text);max-height:62vh;overflow:auto">'+esc(j.md)+'</div>'; }
  else{ bodyHtml='<div style="font:11px var(--muted);margin-bottom:8px">（尚未熔炼，以下为规则式即时预览）</div>'
    +'<div style="white-space:pre-wrap;font:12px/1.8 var(--sans);max-height:62vh;overflow:auto">'+esc(JSON.stringify({
        world:bp.world,characters:(bp.characters||[]).map(c=>c.name+(c.role?'（'+c.role+'）':'')),
        style:bp.style,beats:(bp.beats||[]).length,continuity:bp.continuity_rules},null,1))+'</div>'; }
  $('bpbody').innerHTML=bodyHtml;
  $('bpname').textContent='《'+(j.name||key)+'》总架构';
  $('bpmodal').classList.add('show');
}
window.showBlueprint=showBlueprint;
async function loadBookSkill(key){
  const el=$('bookskill');if(!el)return;
  let sty=null;try{sty=(await (await fetch('/api/style?key='+encodeURIComponent(key))).json()).style;}catch(e){}
  const cur=(sty&&sty.style)||{}, genre=sty?.genre||'';
  let cat=ONB?.style;if(!cat){try{cat=(await (await fetch('/api/onboarding')).json()).style;}catch(e){cat=null;}}
  if(!cat){el.innerHTML='<span style="font:11px var(--muted)">未绑定技能</span>';return;}
  const dims=['金手指','节奏','语言','卷'];
  el.innerHTML='<div style="display:grid;grid-template-columns:1fr 1fr;gap:5px;margin:4px 0">'
    +dims.map(d=>'<div><div style="font:10px var(--muted)">'+d+'</div><select id="bs_'+d+'" style="width:100%;margin-top:2px;padding:5px;background:var(--bg);border:1px solid var(--border);border-radius:6px;color:var(--text)">'+(cat[d]||[]).map(v=>'<option value="'+esc(v)+'"'+(cur[d]===v?' selected':'')+'>'+esc(v)+'</option>').join('')+'</select></div>').join('')
    +'</div><button class="pb run" style="width:100%" onclick="saveBookSkill(\''+key+'\')">💾 保存技能（后续章节按此书写）</button>';
  dims.forEach(d=>{ const b=$('bs_'+d); if(b) cxSelect(b); });
}
window.loadBookSkill=loadBookSkill;
function saveBookSkill(key){
  const dims={};['金手指','节奏','语言','卷'].forEach(d=>{const e=$('bs_'+d);if(e)dims[d]=e.value;});
  fetch('/api/style',{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({key,style:dims})}).then(r=>r.json()).then(j=>{toast('🧩 技能已保存','ok');loadBookSkill(key);});
}
window.saveBookSkill=saveBookSkill;
async function loadBookSched(key){
  const el=$('booksched');if(!el)return;
  let d=null;try{d=(await (await fetch('/api/schedule')).json()).schedules;}catch(e){}
  const s=(d&&d[key])||{};
  el.innerHTML='<div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;font:11.5px var(--sans)">'
    +'<label class="libchip'+(s.enabled?' on':'')+'" id="bsch_en" style="cursor:pointer">'+(s.enabled?'⏱ 定时开':'⏱ 定时关')+'</label>'
    +'<span>每 <input id="bsch_iv" value="'+(s.interval_days||7)+'" style="width:36px;text-align:center;background:var(--bg);border:1px solid var(--border);border-radius:5px;color:var(--text)"> 天</span>'
    +'<span>每次写 <input id="bsch_pr" value="'+(s.per_run||10)+'" style="width:40px;text-align:center;background:var(--bg);border:1px solid var(--border);border-radius:5px;color:var(--text)"> 章</span>'
    +'<button class="pb" onclick="saveBookSched(\''+key+'\')">💾 保存</button></div>'
    +(s.last_note?'<div style="font:10.5px var(--muted);margin-top:3px">最近：'+esc(s.last_note)+'</div>':'');
  $('bsch_en').onclick=()=>$('bsch_en').classList.toggle('on');
}
window.loadBookSched=loadBookSched;
function saveBookSched(key){
  const en=$('bsch_en').classList.contains('on');
  fetch('/api/schedule',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({key,enabled:en,interval_days:+($('bsch_iv').value||7),per_run:+($('bsch_pr').value||10)})}).then(r=>r.json()).then(j=>{toast(en?'⏱ 定时任务已开启（每 N 天写一批）':'⏱ 定时任务已关','ok');loadBookSched(key);});
}
window.saveBookSched=saveBookSched;
async function loadModelRules(){
  const el=$('mrcard');if(!el)return;
  let d=null;try{d=await (await fetch('/api/model_rules')).json();}catch(e){el.innerHTML='';return;}
  const r=d.rules||{}, ov=d.overrides||{};
  const _lbl={context:'上下文窗口',max_tokens:'max_tokens',rpm:'RPM(次/分)',tpm:'TPM(字/分)',backoff_base:'429退避(s)',call_gap:'调用间隔(s)'};
  const inp=n=>'<div><div style="font:10px var(--muted);margin-bottom:2px">'+_lbl[n]+'</div><input id="mr_'+n+'" value="'+(ov[n]!==undefined?ov[n]:(r[n]?r[n]:''))+'" style="width:100%;box-sizing:border-box;padding:5px;background:var(--bg);border:1px solid var(--border);border-radius:6px;color:var(--text)"></div>';
  el.innerHTML='<div style="border:1px solid var(--border);background:var(--panel2);border-radius:12px;padding:10px">'
    +'<div style="font:600 12px var(--sans)">'+esc(d.provider?.name||'当前模型')+' · '+esc(d.provider?.model||'')+'</div>'
    +'<div style="font:11px var(--muted);margin:3px 0 8px">检测到 <b style="color:var(--text)">'+esc(d.vendor||'generic')+'</b> · '+esc(r.note||'')+' · '+(r.generic?'可自由配置':'按该厂规则自动套')+'</div>'
    +'<div style="display:grid;grid-template-columns:1fr 1fr;gap:6px">'
    +['context','max_tokens','rpm','tpm','backoff_base','call_gap'].map(inp).join('')
    +'</div>'
    +'<button class="pb run" style="width:100%;margin-top:8px" onclick="saveModelRules()">💾 保存模型规则</button></div>';
}
window.loadModelRules=loadModelRules;
function saveModelRules(){
  const o={};['context','max_tokens','rpm','tpm','backoff_base','call_gap'].forEach(k=>{const e=$('mr_'+k);if(e&&e.value!=='')o[k]=/^[0-9.]+$/.test(e.value)?+e.value:e.value;});
  fetch('/api/model_rules',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(o)}).then(r=>r.json()).then(j=>toast('🤖 模型规则已保存','ok'));
}
window.saveModelRules=saveModelRules;
// ===== v0.5 M4：多Agent宇宙 —— 子Agent独立配模型 + 全局并发上限 + 批量并发创作 =====
async function renderAgentCard(){
  const el=$('agcard'); if(!el)return;
  let d=null; try{ d=await (await fetch('/api/agents')).json(); }catch(e){ el.innerHTML='<div class="empty">加载失败</div>'; return; }
  const provs=(d.options||[]).map(o=>({id:o.id,name:o.name,models:o.models||[]}));
  const provOpt=p=>provs.map(o=>'<option value="'+o.id+'"'+(o.id===p?' selected':'')+'>'+esc(o.name)+'</option>').join('');
  const modelOpts=(p,m)=>{ const o=provs.find(x=>x.id===p); const ms=(o&&o.models)||[];
    return ms.map(x=>'<option value="'+esc(x)+'"'+(x===m?' selected':'')+'>'+esc(x)+'</option>').join('')+'<option value="">（回落 stage/默认）</option>'; };
  let h='<div style="border:1px solid var(--border);background:var(--panel2);border-radius:12px;padding:10px">';
  h+='<div style="font:11px var(--muted);margin-bottom:6px">🤖 每个子Agent可挂独立供应商/模型，把创作/审稿/重写负载摊开，避免单一API并发过高（全局并发上限 <b>'+d.max_global_agents+'</b>）：</div>';
  (d.agents||[]).forEach(a=>{
    h+='<div style="margin-bottom:8px;padding:7px;background:var(--bg);border:1px solid var(--border);border-radius:9px">'+
      '<div style="font:600 12px">'+a.label+' <span style="font:10px var(--muted);font-weight:400">'+a.desc+' · '+a.effective+'</span></div>'+
      '<div style="display:flex;gap:6px;margin-top:5px;flex-wrap:wrap">'+
      '<select id="ag_p_'+a.agent+'" style="flex:1;min-width:110px;padding:4px;background:var(--bg);border:1px solid var(--border);border-radius:6px;color:var(--text)">'+(a.provider_id?'<option value="'+esc(a.provider_id)+'" selected>'+esc(a.provider_id)+'</option>':'')+'<option value="">默认供应商</option>'+provOpt(a.provider_id)+'</select>'+
      '<select id="ag_m_'+a.agent+'" style="flex:1;min-width:110px;padding:4px;background:var(--bg);border:1px solid var(--border);border-radius:6px;color:var(--text)">'+modelOpts(a.provider_id,a.model)+'</select>'+
      '<button class="pb" style="white-space:nowrap" onclick="saveAgentBinding(\''+a.agent+'\')">💾 保存</button></div></div>';
  });
  h+='<div style="display:flex;gap:6px;align-items:center;margin-top:4px"><span style="font:11px var(--muted)">全局并发上限</span>'+
     '<input id="ag_g" type="number" min="1" max="16" value="'+d.max_global_agents+'" style="width:56px;padding:4px;background:var(--bg);border:1px solid var(--border);border-radius:6px;color:var(--text)">'+
     '<button class="pb" onclick="saveMaxGlobal()">应用</button></div>';
  h+='<div style="font:10.5px var(--muted);margin-top:8px;line-height:1.5">🚀 多书并发创作：选多本书点「并发创作」，每书一个Agent线程，LLM并发受上方上限限流排队（防429）。</div>'+
     '<button class="pb" style="width:100%;margin-top:6px" onclick="dispatchBooks()">🚀 并发创作选中书（最多8本）</button></div>';
  el.innerHTML=h;
}
window.renderAgentCard=renderAgentCard;
function saveAgentBinding(agent){
  const p=$('ag_p_'+agent), m=$('ag_m_'+agent);
  fetch('/api/agents-set',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({agent,provider_id:p?p.value:'',model:m?m.value:''})})
   .then(r=>r.json()).then(()=>toast('🤖 「'+agent+'」模型已保存','ok'));
}
window.saveAgentBinding=saveAgentBinding;
function saveMaxGlobal(){
  const g=$('ag_g'); const n=g?+g.value:4;
  fetch('/api/agents-maxglobal',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({n})})
   .then(r=>r.json()).then(j=>toast('全局并发上限 → '+(j.max_global_agents||n),'ok'));
}
window.saveMaxGlobal=saveMaxGlobal;
function dispatchBooks(){
  const sel=(window._libCache||[]).filter(x=>(x.state==='in_progress'||x.state==='completed')&&!x.archived).map(x=>x.key);
  if(!sel.length) return toast('没有可创作的书（先在左侧选书/新建）','err');
  if(!confirm('并发创作这 '+(sel.length>8?8:sel.length)+' 本书？（每书一个Agent，LLM受全局上限限流）')) return;
  fetch('/api/agents-dispatch',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({keys:sel.slice(0,8)})})
   .then(r=>r.json()).then(j=>toast('🚀 已启动 '+(sel.length>8?8:sel.length)+' 本书并发创作（完成弹通知）','ok')).catch(()=>toast('并发创作失败','err'));
}
window.dispatchBooks=dispatchBooks;
function switchView(v){
  const ms=$('manuscript'),msgs=$('msgs'),ib=$('inputbar');
  document.querySelectorAll('#viewsw button').forEach(b=>b.classList.toggle('on',b.dataset.v===v));
  if(v==='ms'){ms.style.display='block';msgs.style.display='none';loadManuscript(curSession||curKey);}
  else{ms.style.display='none';msgs.style.display='';ib.style.display='';stopMs();
    if(window.loadChatLive)loadChatLive(curSession||curKey);}   // v0.7.x 对话区逐章直播
}
window._chatModeBtn=$('chmode');
window.switchView=switchView;
document.querySelectorAll('#viewsw button').forEach(b=>b.onclick=()=>switchView(b.dataset.v));
async function loadManuscript(key){
  if(!key){$('msbody').innerHTML='<span style="color:var(--muted)">未选中书。先在左侧选一本书，或点「＋新建」。</span>';$('msline').textContent='';$('msprog').textContent='';return;}
  const tk=_viewToken;   // v0.6 A：视图代际守卫——每个 await 后若已切书则弃旧响应
  let st={};try{st=await (await fetch('/api/status?key='+encodeURIComponent(key))).json();}catch(e){}
  if(tk!==_viewToken||key!==(curSession||curKey))return;
  let pv={};try{pv=await (await fetch('/api/preview?key='+encodeURIComponent(key))).json();}catch(e){}
  if(tk!==_viewToken||key!==(curSession||curKey))return;
  let us={};try{us=await (await fetch('/api/usage?key='+encodeURIComponent(key))).json();}catch(e){}
  if(tk!==_viewToken||key!==(curSession||curKey))return;
  const u=us.usage||{};
  const done=(pv.chapters||[]).filter(c=>c.status==='completed').length, tot=(pv.chapters||[]).length;
  const _state = st.awaiting_title?'⏸ 待选书名':(st.state==='in_progress'?'✍️ 创作中':st.state==='validating'?'🔁 校验中':st.state==='completed'?'✅ 已成书':(st.state||'—'));
  const _curCh=(st.state==='in_progress')?(' · 正在写第 '+Math.min((st.done!=null?st.done:done)+1,(st.total!=null?st.total:tot))+' 章'):'';
  $('msprog').innerHTML='第 '+(st.done!=null?st.done:done)+'/'+(st.total!=null?st.total:tot)+' 章 · '+((u.total_tokens||0).toLocaleString())+' token';
  $('msline').innerHTML='📄 稿件 · <b>'+esc(pv.name||key)+'</b> · <span style="color:var(--accent);font-weight:600">'+_state+'</span>'+_curCh
    +' · 写到第 <b>'+(st.done!=null?st.done:done)+'</b>/'+(st.total!=null?st.total:tot)+' 章 · 共 <b>'+((st.words||pv.total_words||0))+'</b> 字 · 累计 <span class="tk">'+((u.total_tokens||0).toLocaleString())+' token</span>（'+(u.calls||0)+' 次调用）'
    +'<br><span style="font-size:10.5px">'+(st.events?('· '+esc((st.events||[]).slice(-1)[0]||'')):(u.by_stage?Object.entries(u.by_stage).map(([k,v])=>k+' '+(v.total||0)).join(' · '):''))+(u.last?' · 最近 '+u.last.stage+' '+ (u.last.total||0):'')+'</span>';
  renderMsChart(key, pv);   // v0.5 M1：逐章评分条
  let txt=(pv.text||'').trim();
  const isW=(st.state==='in_progress'||st.state==='validating'||st.state==='releasing');
  // v0.3.5 打字机：换书重置；写作中逐字揭示新增正文，已完成的书整段显示
  if(_msKey!==key){ _msKey=key; _msRevealed=isW?Math.min((txt||'').length,500):(txt||'').length; stopMs(); }
  _msFull=(pv.text||'').trim(); _msWriting=isW;
  _msRevealed=Math.min(_msRevealed,_msFull.length);
  if(!txt && !isW){ _msFull=''; _msRevealed=0; $('msbody').innerHTML='<span style="color:var(--muted)">（尚未生成正文。切到「💬 对话」直接开写，或点上方快捷操作「▶ 续写」。）</span>'; return; }
  if(!isW){ _msRevealed=_msFull.length; renderMsBody(_msFull,false); }
  else { if(_msRevealed<_msFull.length)startMs(); else renderMsBody(_msFull,true); }
  scrollMsBottom();
}
window.loadManuscript=loadManuscript;
// ===== v0.5 M1：逐章评分条（<90 高亮，可逐章/多选重写）=====
function renderMsChart(key, pv){
  const el=$('mschart'); if(!el)return;
  const pcs=(pv&&pv.per_chapter)||[], pl=pv?.pass_line||90;
  const done=(pv&&pv.chapters)||[];
  if(!pcs.length && !done.length){ el.innerHTML=''; return; }
  const scored=pcs.length;
  const below=pcs.filter(x=>x.score!=null&&x.score<pl).length;
  let h='<div style="display:flex;gap:8px;align-items:center;padding:5px 10px;margin:2px 0 8px;background:var(--card);border:1px solid var(--border);border-radius:10px;min-height:34px">';
  h+='<span style="font:11px var(--muted);white-space:nowrap;flex:0 0 auto">📊 逐章评分（线 '+pl+'）'+(scored?' · 已评 '+scored+' 章':' · 尚未评分')+(below?' · <b style="color:#f59e0b">'+below+' 章未达标</b>':'')+'</span>';
  h+='<div style="flex:1 1 auto;overflow-x:auto;overflow-y:hidden;display:flex;gap:5px;align-items:center;white-space:nowrap">';
  const items=(pcs.length?pcs:done.map(c=>({ch:c.n,score:null,status:'unscored',weak:[]})));
  h+=items.map(x=>{
    const s=x.score, bad=(s!=null&&s<pl);
    const bg= s==null? 'transparent': (bad? 'rgba(245,158,11,.15)':'rgba(58,210,155,.12)');
    const bd= bad? '#f59e0b':'var(--border)';
    return '<span data-ch="'+x.ch+'" class="msscore" style="flex:0 0 auto;cursor:pointer;background:'+bg+';border:1px solid '+bd+';border-radius:8px;padding:2px 7px;font:11px;'+(bad?'color:#f59e0b;font-weight:700':'color:var(--text)')+'">'+
      '第'+x.ch+'章 '+(s!=null? s : (x.status==='unscored'?'—':'未评')) +
      (bad?' ⚠️':'')+(x.weak&&x.weak.length?' <i style="opacity:.7">('+x.weak.slice(0,2).join('/')+')</i>':'')+'</span>';
  }).join('');
  h+='</div>';
  if(scored && below){
    h+='<button class="msrwb" id="msrwb" style="flex:0 0 auto;background:var(--accent);color:#0b1020;border:0;border-radius:8px;padding:4px 10px;font:12px;font-weight:700;cursor:pointer;white-space:nowrap">🔁 重写全部未达标（'+below+' 章）</button>';
  }
  h+='</div>';
  el.innerHTML=h;
  // 逐章点击=重写该章
  el.querySelectorAll('.msscore').forEach(ch=>{
    ch.onclick=()=>{ triggerRewrite(key,[+ch.dataset.ch]); };
    ch.onmouseenter=()=>ch.style.filter='brightness(1.15)';
    ch.onmouseleave=()=>ch.style.filter='';
  });
  const rw=$('msrwb');
  if(rw) rw.onclick=()=>{
    const sel=pcs.filter(x=>x.score!=null&&x.score<pl).map(x=>x.ch);
    if(!sel.length) return toast('没有未达标章节可重写','err');
    triggerRewrite(key, sel);
  };
}
window.renderMsChart=renderMsChart;
// ===== v0.5 M3：中间台自然语言指令 → 结构化动作 =====
function triggerRewrite(key, chapters){
  // v0.8.0：留在对话页，弹窗只做「确认」（选章/维度）；点开始→自动回对话页逐章直播（可切别的书）
  const who=(chapters&&chapters.length)?('第 '+chapters.join('、')+' 章'):' 全书弱章';
  bubble('bot','🔁 重写'+esc(who)+' —— 在弹窗里增减章节/维度，点「开始」就<b>自动回到对话页</b>逐章直播（可切别的书改别的书）…','');
  openRewriteWorkbench(key, chapters);
}
window.triggerRewrite=triggerRewrite;
let _rwPoll={};
function pollRewriteKey(key){
  if(_rwPoll[key])clearInterval(_rwPoll[key]);
  const t0=Date.now();
  _rwPoll[key]=setInterval(async()=>{
    try{
      const d=await (await fetch('/api/rewrite-log?key='+encodeURIComponent(key))).json();
      if(!d.running){
        clearInterval(_rwPoll[key]);
        const isCur=(key===(curSession||curKey));   // v0.6 A：只刷当前书视图，不串台
        if(isCur){
          if(d.result&&d.result.error){ bubble('bot','⚠️ 重写失败：'+esc(d.result.error),''); $('msrw').innerHTML=renderRewriteResultCard(d.result,key); }
          else { $('msrw').innerHTML=renderRewriteResultCard(d.result,key); bubble('bot','✅ 重写完成：'+(d.result?d.result.before+' → '+d.result.after:'详见 16-重写记录')+'。结果卡已出现在稿件区（同预览定向重写）。',''); }
          loadManuscript(key);
        }
        loadLibrary();
      } else if(Date.now()-t0>420000){ clearInterval(_rwPoll[key]); }
    }catch(e){}
  },6000);
}
async function showScoreTable(key){
  const j=await (await fetch('/api/preview?key='+encodeURIComponent(key))).json();
  const pcs=j.per_chapter||[], pl=j.pass_line||90;
  let b='📊 <b>《'+esc(j.name||key)+'》逐章评分</b>（达标线 '+pl+'）：'+
    (pcs.length?'<br><table style="font:12px;margin:6px 0;width:100%;border-collapse:collapse"><tr style="color:var(--muted)"><th style="text-align:left">章</th><th>分</th><th style="text-align:left">薄弱维度</th><th>达标</th></tr>'+
    pcs.map(x=>{const bad=x.score!=null&&x.score<pl;return '<tr><td style="text-align:left;padding:2px 6px">第'+x.ch+'章</td><td style="color:'+(bad?'#f59e0b':'#3ad29b')+';font-weight:700">'+(x.score!=null?x.score:'—')+'</td><td style="text-align:left;opacity:.85">'+(x.weak||[]).join('、')+'</td><td>'+(bad?'⚠️ 未达标':'✅')+'</td></tr>';}).join('')+
    '</table>':'（尚未逐章评分——完成写作或跑一次审稿后自动评分）')+(pcs.length?'<br>👉 直接告诉我「重写第N章」「重写第N章那段」「全书改写」即可。':'');
  bubble('bot',b,'');
}
async function doRewriteSection(key, chap, text){
  // 从指令里抓一段定位文字（去掉动词/章号，剩下的当片段）
  const match=(text.replace(/(改写|重写|把|将|第\d+章|那段|那段话|一小段|一段)/g,' ').trim()).slice(0,30);
  const j=await (await fetch('/api/rewrite-section',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({key,chapter:chap,match,instruction:'把这一段写得更抓人，去掉 AI 腔，加细节与张力'})})).json();
  if(j.error) bubble('bot','⚠️ '+esc(j.error)+'（可以再说清楚一点是哪一句/哪段）','');
  else bubble('bot','✒️ 第 '+chap+' 章该段已改写。<br><b style="opacity:.8">原：</b>'+esc((j.orig||'').slice(0,120))+'<br><b style="opacity:.8">新：</b>'+esc((j.new||'').slice(0,120)),'');
}
async function execCmd(cr, text){
  const k=cr.key;
  switch(cr.action){
    case 'rewrite_chapter': triggerRewrite(k,[cr.chapter]); break;      // 弹窗确认 → 自动回对话页逐章改写
    case 'rewrite_section': bubble('bot','✒️ 收到：改写第 '+cr.chapter+' 章里的一小段…',''); await doRewriteSection(k,cr.chapter,text); break;
    case 'rewrite_all': triggerRewrite(k,null); break;                 // 全书改写：弹窗确认 → 对话页逐章
    case 'scores': bubble('bot','📊 正在拉取逐章评分…',''); await showScoreTable(k); break;
    default: break;
  }
  // v0.8.0：全部留在对话页（不再跳稿件）——对话框是万能的，随时下各种修改指令
}
window.execCmd=execCmd;
// ===== v0.5 M2：放行弹窗「重写并看稿件」——进入该书会话工作台，实时看书写 =====
function releaseRewrite(key, chapters){
  closeRelease();
  curKey=key; curSession=key; loadLibrary(); startPolling();
  // 改变重写状态：侧栏该书显示「重写中」，中间切到稿件视图并实时刷新
  triggerRewrite(key, chapters);   // 内部 switchView('ms')+loadManuscript+轮询
  if(window._libItem(key)){ const it=_libItem(key); it.state='validating'; it.status_note='重写中'; }
  bubble('bot','🔁 已进入《'+esc(_libItem(key)?_libItem(key).name:key)+'》的重写：带要求逐章重写'+(chapters&&chapters.length?'（第 '+chapters.join('、')+' 章）':'（全书弱章）')+'，稿件区实时刷新书写内容。完成会弹通知。','');
}
window.releaseRewrite=releaseRewrite;
// ===== v0.3.5 打字机逐字显示（正在写/校验时，新增正文逐字出现）=====
let _msFull='', _msKey='', _msRevealed=0, _msWriting=false, _msTick=null;
function renderMsBody(txt,typing){
  const el=$('msbody'); if(!el)return;
  const html=txt.split(/(\n+#[^\n]+)/g).map(seg=>{
    if(/^#[\s]/.test(seg))return '<div class="mschap">'+esc(seg.replace(/^#+\s*/,'').trim())+'</div>';
    return esc(seg);
  }).join('');
  el.innerHTML=html+(typing?'<span style="color:var(--accent);font-weight:700">▍</span>':'');
}
function scrollMsBottom(){ const m=$('manuscript'); if(m)m.scrollTop=m.scrollHeight; }
function stopMs(){ if(_msTick){clearInterval(_msTick);_msTick=null;} }
function startMs(){
  stopMs();
  _msTick=setInterval(()=>{
    if(_msRevealed>=_msFull.length){ stopMs(); renderMsBody(_msFull,_msWriting); return; }
    _msRevealed=Math.min(_msFull.length,_msRevealed+22);   // 每 tick 揭示 22 字 ≈ 700+ 字/秒
    renderMsBody(_msFull.slice(0,_msRevealed),true);
    scrollMsBottom();
  },28);
}
window.renderMsBody=renderMsBody; window.startMs=startMs; window.stopMs=stopMs;
// ===== v0.7.x 对话区「逐章直播打字机」：一章一条气泡 · 逐字往外蹦 · 写满一章自动出新气泡 =====
const CL={ key:null, chapEls:{}, revealed:{}, mode:'type', tw:null, activeN:null };
function stopChatTw(){ if(CL.tw){ clearInterval(CL.tw); CL.tw=null; } }
function _chapBodyHTML(t, cursor){
  const html=t.split(/(\n+#[^\n]+)/g).map(seg=>{
    if(/^#[\s]/.test(seg)) return '<div class="chchapmark">'+esc(seg.replace(/^#+\s*/,'').trim())+'</div>';
    return esc(seg);
  }).join('');
  return html + (cursor ? '<span class="twcur">▍</span>' : '');
}
function _scrollMsgs(){ const m=msgBox; if(m) m.scrollTop=m.scrollHeight; }
// 建/取某章气泡（data-chapn 去重，绝不重复建）
function _chapBubble(n, title, fullText){
  let rec=CL.chapEls[n];
  if(rec && rec.root.isConnected){ return rec; }
  const d=document.createElement('div');
  d.className='msg chap'; d.dataset.chapn=n;
  d.innerHTML='<div class="ava">📖</div><div class="bubble" style="max-width:92%">'+
    '<div class="chhead"><span class="chttl">第 '+n+' 章'+((title&&title!=='续写')?' · '+esc(title):'')+'</span><span class="chstat"></span></div>'+
    '<div class="chbody"></div><div class="chmore"></div></div>';
  msgBox.appendChild(d);
  rec={ root:d, ttl:d.querySelector('.chttl'), stat:d.querySelector('.chstat'), body:d.querySelector('.chbody'), more:d.querySelector('.chmore'), fullText, expanded:false };
  rec.more.onclick=()=>{ rec.expanded=!rec.expanded; _paintChap(n); };
  CL.chapEls[n]=rec;
  return rec;
}
// 渲染某章气泡（活跃章=逐字；已完成章=长文折叠）
function _paintChap(n){
  const rec=CL.chapEls[n]; if(!rec)return;
  const full=rec.fullText||'';
  if(n===CL.activeN && CL._writing){
    const typing=(CL.mode==='type');
    const reveal=typing? Math.min(CL.revealed[n]||0, full.length) : full.length;
    rec.body.innerHTML=_chapBodyHTML(full.slice(0,reveal), typing && reveal<full.length);
    rec.stat.innerHTML='<span style="color:var(--accent);font-weight:600">✍️ 创作中 '+Math.round((full.length?reveal/full.length:0)*100)+'%</span>';
    rec.more.textContent=''; rec.more.style.display='none';
  } else {
    if(full.length>1500 && !rec.expanded){
      rec.body.innerHTML=_chapBodyHTML(full.slice(0,500), false);
      rec.more.textContent='▾ 展开本章全文（'+full.length+' 字）'; rec.more.style.display='';
    } else {
      rec.body.innerHTML=_chapBodyHTML(full, false);
      rec.more.textContent=full.length>1500?'▴ 收起':''; rec.more.style.display=full.length>1500?'':'none';
    }
    rec.stat.innerHTML='<span style="color:#3ad29b">✅ 已完成 · '+full.length+' 字</span>';
  }
  _scrollMsgs();
}
// 逐字引擎：30ms 推进活跃章，写满自动交给下一章
function startChatTw(){
  stopChatTw();
  if(CL.mode!=='type')return;
  CL.tw=setInterval(()=>{
    const n=CL.activeN; if(n==null)return;
    const rec=CL.chapEls[n]; const full=(rec&&rec.fullText||'').length;
    const r=CL.revealed[n]||0;
    if(r>=full){ stopChatTw(); return; }        // 本章写满 → 停（等下一轮出新章）
    CL.revealed[n]=Math.min(full, r+22);
    _paintChap(n);
  },30);
}
// 拉取并驱动（每轮 startPolling 调；切书/换视图重置）
async function loadChatLive(key){
  if(!key)return;
  const tk=_viewToken;
  if(CL.key!==key){ CL.key=key; CL.chapEls={}; CL.revealed={}; CL.activeN=null; stopChatTw(); }
  let st={}, pv={};
  try{ st=await (await fetch('/api/status?key='+encodeURIComponent(key))).json(); }catch(e){}
  if(tk!==_viewToken || key!==(curSession||curKey))return;
  try{ pv=await (await fetch('/api/preview?key='+encodeURIComponent(key))).json(); }catch(e){}
  if(tk!==_viewToken || key!==(curSession||curKey))return;
  const writing=['in_progress','validating','releasing'].includes(st.state);
  CL._writing=writing;
  const cf=(pv.chapters_full||[]).slice().sort((a,b)=>(a.n||0)-(b.n||0));
  // 清理已不存在的章节气泡（书被清空等）
  Object.keys(CL.chapEls).forEach(n=>{ if(!cf.find(c=>c.n==+n)) delete CL.chapEls[n]; });
  if(!cf.length){
    if(writing){ const rec=_chapBubble(0, null, '');
      rec.ttl.textContent='✍️ 《'+(pv.name||key)+'》开写中（正在规划 / 生成第 1 章，逐字稍等）…';
      rec.body.innerHTML=''; rec.stat.innerHTML=''; rec.more.style.display='none'; }
    CL.activeN=null; stopChatTw(); return;
  }
  cf.forEach(c=>{ const rec=_chapBubble(c.n, c.title, c.text||''); rec.fullText=c.text||''; });
  // 活跃章 = 正在写时的最后一章；旧章 revealed 直接拉满（不重打）
  CL.activeN = writing ? cf[cf.length-1].n : null;
  cf.forEach(c=>{ if(c.n!==CL.activeN){ CL.revealed[c.n]=(c.text||'').length; } });
  if(CL.activeN!=null && CL.revealed[CL.activeN]===undefined) CL.revealed[CL.activeN]=0;   // 新章从头打
  cf.forEach(c=>_paintChap(c.n));
  if(writing && CL.mode==='type') startChatTw(); else stopChatTw();
}
window.loadChatLive=loadChatLive;
// 逐字/直显 开关
function toggleChatMode(){ CL.mode=(CL.mode==='type'?'instant':'type');
  if(window._chatModeBtn)_chatModeBtn.textContent=(CL.mode==='type'?'🎞 逐字':'⚡ 直显');
  if(CL._writing && CL.mode==='type') startChatTw(); else { if(CL.activeN!=null){CL.revealed[CL.activeN]=(CL.chapEls[CL.activeN]||{}).fullText?.length||0;} stopChatTw(); CL.activeN!=null&&_paintChap(CL.activeN); }
}
window.toggleChatMode=toggleChatMode;
async function loadTokenLedger(key){
  const el=$('tkcard');if(!el||!key)return;
  let us={};try{us=await (await fetch('/api/usage?key='+encodeURIComponent(key))).json();}catch(e){el.innerHTML='';return;}
  const u=us.usage||{},g=us.global||{},bs=u.by_stage||{};
  el.innerHTML='<div style="border:1px solid var(--border);background:var(--panel2);border-radius:10px;padding:10px 12px;font:11.5px/1.7 var(--sans);color:var(--muted)">'
    +'<div style="font:600 13px var(--sans);color:var(--text)">全书累计 <span style="color:var(--accent)">'+((u.total_tokens||0).toLocaleString())+'</span> token · '+(u.calls||0)+' 次调用</div>'
    +'<div style="margin:4px 0">输入 '+((u.total_prompt||0).toLocaleString())+' · 输出 '+((u.total_completion||0).toLocaleString())+'</div>'
    +(Object.keys(bs).length?('<div style="display:flex;flex-wrap:wrap;gap:6px;margin-top:4px">'+Object.entries(bs).map(([k,v])=>'<span class="libchip" style="cursor:default">'+k+' <b style="color:var(--text)">'+(v.total||0).toLocaleString()+'</b></span>').join('')+'</div>'):'')
    +'<div style="margin-top:7px;font-size:10.5px;border-top:1px solid var(--border);padding-top:6px">全部作品累计：'+((g.total_tokens||0).toLocaleString())+' token · '+(g.calls||0)+' 次调用</div></div>';
}
window.loadTokenLedger=loadTokenLedger;
async function loadGlobalToken(){
  const el=$('libtk');if(!el)return;
  let g={};try{g=(await (await fetch('/api/usage')).json()).global||{};}catch(e){}
  el.innerHTML='🔢 全部作品累计消耗 <b style="color:var(--accent)">'+((g.total_tokens||0).toLocaleString())+'</b> token · '+(g.calls||0)+' 次调用';
}
window.loadGlobalToken=loadGlobalToken;
/* ===== v0.3.3：自定义深色下拉（替代原生 <select> 弹层，彻底修复「下拉箭头不好使/看不清」）=====
   原生 <select> 的弹层由操作系统渲染，在深色玻璃拟态 UI 下不可控（macOS/WebKit 尤甚）。
   方案：把原生 select 隐藏但保留（.value/.onchange/.options 全部继续可用，提交逻辑零改动），
   在其后插入一个自定义深色下拉面板；点选后写回原生 value 并派发 change。MutationObserver
   监听 options 变化（向导 sel() 填值、供应商/模型切换、按题材 preset 联动）自动重建面板。 */
function cxSelect(idOrEl){
  const sel=(typeof idOrEl==='string')?$(idOrEl):idOrEl;
  if(!sel||sel._cxd)return sel;
  sel._cxd=true; sel.style.display='none';
  const wrap=document.createElement('div'); wrap.style.cssText='position:relative;display:block;min-width:0';
  sel.insertAdjacentElement('afterend',wrap);
  const btn=document.createElement('button'); btn.type='button';
  btn.style.cssText='width:100%;box-sizing:border-box;display:flex;justify-content:space-between;align-items:center;gap:8px;background:rgba(255,255,255,.06);border:1px solid var(--border);border-radius:9px;padding:8px 11px;color:var(--text);font-size:13px;font-family:inherit;cursor:pointer;text-align:left';
  const val=document.createElement('span'); val.style.cssText='flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap';
  const arr=document.createElement('span'); arr.textContent='▾'; arr.style.cssText='color:var(--muted);font-size:12px;flex:none';
  btn.append(val,arr); wrap.append(btn);
  const panel=document.createElement('div');
  panel.style.cssText='display:none;position:fixed;z-index:99;background:#101426;border:1px solid var(--border);border-radius:9px;max-height:240px;overflow:auto;box-shadow:0 12px 32px rgba(0,0,0,.55)';
  document.body.append(panel);
  const isSel=(o)=>o===sel.options[sel.selectedIndex];
  function sync(){ const i=sel.selectedIndex; val.textContent=(i>=0&&sel.options[i])?sel.options[i].textContent:'(未选)'; }
  function build(){
    panel.innerHTML='';
    Array.from(sel.options).forEach(o=>{
      const it=document.createElement('div'); it.textContent=o.textContent||o.value;
      it.style.cssText='padding:8px 12px;font-size:13px;color:var(--text);cursor:pointer;'+(isSel(o)?'background:rgba(108,140,255,.22);':'');
      it.onmouseenter=()=>{ if(!isSel(o)) it.style.background='rgba(255,255,255,.08)'; };
      it.onmouseleave=()=>{ it.style.background=isSel(o)?'rgba(108,140,255,.22)':''; };
      it.onclick=()=>{ sel.value=o.value; sel.dispatchEvent(new Event('change',{bubbles:true})); sync(); close(); };
      panel.append(it);
    });
  }
  function open(){
    build(); sync(); panel.style.display='block'; panel.style.transform='';
    const r=btn.getBoundingClientRect();
    const pw=Math.max(r.width,150);
    panel.style.width=pw+'px'; panel.style.left=r.left+'px';
    const below=(r.bottom+2+Math.min(240,panel.scrollHeight))<=innerHeight;
    if(below){ panel.style.top=(r.bottom+2)+'px'; }
    else{ panel.style.top=(r.top-2)+'px'; panel.style.transform='translateY(-100%)'; }
  }
  function close(){ panel.style.display='none'; }
  btn.onclick=(e)=>{ e.stopPropagation(); _cxCtx.forEach(c=>{if(c.panel!==panel)c.close();}); (panel.style.display==='block')?close():open(); };
  const ctx={sel,wrap,panel,close}; sel._cxpanel=panel; sel._cxbtn=btn;
  ctx.mo=new MutationObserver(()=>{ build(); sync(); }); ctx.mo.observe(sel,{childList:true,subtree:true});
  _cxCtx.push(ctx); _cxBindDoc(); sync();
  return sel;
}
let _cxCtx=[],_cxDocBound=false;
function _cxBindDoc(){
  if(_cxDocBound)return; _cxDocBound=true;
  document.addEventListener('click',e=>{
    _cxCtx=_cxCtx.filter(c=>{ if(!c.wrap.isConnected){ c.mo.disconnect(); c.close(); return false; } return true; });
    _cxCtx.forEach(c=>{ if(!c.wrap.contains(e.target)&&!c.panel.contains(e.target)) c.close(); });
  });
  document.addEventListener('keydown',e=>{ if(e.key==='Escape') _cxCtx.forEach(c=>c.close()); });
}
window.cxSelect=cxSelect;
function cxApplyAll(){
  ['pselect','mselect','libsort','mpreset','pvch','ob_genre','ob_persp','ob_tone','ob_chap','ob_hand','ob_pace','ob_lang','ob_prov','ob_model','ob_style']
    .forEach(id=>cxSelect(id));
}
window.cxApplyAll=cxApplyAll;
function toggleSess(){const c=$('sessions');c.classList.toggle('collapsed');$('sestog').textContent=c.classList.contains('collapsed')?'»':'«';}
window.toggleSess=toggleSess;
function initDrag(){
  [['dragL','sessions'],['dragR','side']].forEach(([id,col])=>{
    const h=$(id),el=$(col);let sx=0,sw=0;
    h.onmousedown=e=>{sx=e.clientX;sw=el.offsetWidth;document.body.style.userSelect='none';h.classList.add('hot');
      const mv=ev=>{let w=sw+((col==='side')?(sx-ev.clientX):(ev.clientX-sx));w=Math.max(col==='sessions'?52:260,Math.min(col==='sessions'?440:680,w));el.style.width=w+'px';};
      const up=()=>{document.removeEventListener('mousemove',mv);document.removeEventListener('mouseup',up);h.classList.remove('hot');document.body.style.userSelect='';localStorage['nbot_w_'+col]=el.style.width;};
      document.addEventListener('mousemove',mv);document.addEventListener('mouseup',up);};
  });
  [['sessions',250],['side',380]].forEach(([col,dft])=>{const v=localStorage['nbot_w_'+col];if(v)$(col).style.width=v;});
}
window.initDrag=initDrag;

refreshProjects();
renderSessions(); initDrag(); startStudio(); emptyGuide();   // v0.7 R5：工作室总览 + 小白空态引导
// v0.8.0：版本统一——顶栏徽标 + 页面标题 都取 /api/version（与 VERSION 文件同源），全站展示趋向一致
window.APPVER='0.8.0';
fetch('/api/version').then(r=>r.json()).then(j=>{ const v='v'+(j.version||window.APPVER); const b=document.getElementById('verbadge'); if(b)b.textContent=v; if(!/\b(bkt|cxt)=/.test(location.search))document.title='神笔 · 小说创作机器人 '+v; }).catch(()=>{});
(function(){cxApplyAll();var q=new URLSearchParams(location.search),b=q.get('book'),t=q.get('tab'),v=q.get('view'); if(b)selectBook(b); if(t&&['art','set','lib'].includes(t))setTimeout(()=>sideTab(t),300); if(v==='ms')setTimeout(()=>switchView('ms'),500); if(q.get('onb'))setTimeout(()=>openOnb(),250); if(q.get('bkt'))setTimeout(()=>{const m=document.querySelector('[data-menu]');if(m){m.click();setTimeout(()=>{document.title='BKT items='+(_bkPanel?_bkPanel.querySelectorAll('div').length:0);},250);}else document.title='BKT no-anchor';},900); if(q.get('cxt'))setTimeout(async()=>{try{await openOnb();await new Promise(r=>setTimeout(r,250));const out={};['ob_chap','ob_hand','ob_prov'].forEach(id=>{const cs=$(id);out[id]={hidden:cs.style.display==='none',wrapped:!!cs._cxd,btn:!!cs._cxbtn};if(cs._cxbtn){cs._cxbtn.click();out[id].panelOpen=cs._cxpanel.style.display==='block';out[id].opts=cs._cxpanel.querySelectorAll('div').length;const op=cs._cxpanel.querySelectorAll('div');if(op[1]){op[1].click();out[id].valAfter=cs.value;}}});document.title='CXT '+JSON.stringify(out);}catch(e){document.title='CXT_ERR '+e;}}),50;})();
loadProviders();
loadProviderPicker();
document.getElementById('addprov').onclick=openProvModal;
document.getElementById('mbind').onclick=bindProv;
document.getElementById('provmodal').addEventListener('click',e=>{if(e.target.id==='provmodal')closeProvModal();});
document.getElementById('pvmodal').addEventListener('click',e=>{if(e.target.id==='pvmodal')closePvModal();});
bubble('bot','👋 你好，我是<b>神笔</b>——「一幕·神笔 · ShenBi NovelCraft」原创创作系统（v'+(window.APPVER||'0.8.0')+' 三栏工作台：左·会话=书 / 中·该书对话 / 右·产物·设置·作品库；并发写多本 · 定时任务 · 题材×风格技能 · 模型规则引擎）。\n直接丢个主题给我，例如：\n「写一部悬疑小说，退休刑警被诬陷杀人，10章」\n「都市爽文，女主，20章，轻松基调」\n我会完成 规划（故事圣经/线索账本/时间线+黄金三章门）→逐章创作（题材craft+反AI腔）→确定性引擎+五角色审校+百分制达标→成书 全流程，中途自动报进度；写完后右边可「👁 预览」「📝 审稿」「📊 质量报告」「⬇ 成书」。\n当前版本 v'+(window.APPVER||'0.8.0')+'。');
